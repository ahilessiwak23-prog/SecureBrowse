# SPEC – SecureBrowse + JARVIS 2.0 (Arbeitsvertrag für alle Beteiligten)

Stand 21.11.2026. Ziel: Die App ist „50× besser“ im Sinne des Nutzers (Herkules, 18, schreibt Deutsch). Er hat sich gewünscht:

1. JARVIS als KI im blauen Hologramm-Look, mit Zugriff auf Kamera + Mikrofon, wählbaren Stimmen (männlich/weiblich/neutral).
2. Viel bessere Einstellungen: Info zur App, **10× auf die Version tippen → neuer Schalter** → Passwort-Abfrage → Admin-Bereich (u. a. API-Schlüssel für die KI).
3. Virenschutz für die KI, Schutz vor Anleitungen zu illegalen Waffen und Drogen.
4. Inkognito-Modus, Dateien-/Cache-Verwaltung in den Einstellungen.
5. Eigenes Konto: E-Mail-Registrierung/-Login, Anmeldung mit Google, mit Apple-ID.
6. Farbthemen (Standard Jarvis-Blau, dazu Pink usw.), wählbare Hintergründe, Beispielbilder (nur **eigene, urheberrechtsfreie** – nichts Geschütztes).

## Harte Regeln (gelten für ALLE Teile)

* **Ehrlichkeit vor Glanz.** Nichts als „getestet“ oder „funktioniert“ behaupten, was nicht ausgeführt wurde. Der Android-Code wurde nie gebaut (kein SDK, kein Netz in der Arbeitsumgebung). Reine Kotlin-Logik (ohne `android.*`) wird mit dem mitgelieferten Kotlin-Compiler kompiliert und gegen die gemeinsamen Testfälle (`tests/vectors/*.json`) ausgeführt. Alles andere ist „nur gelesen, nicht kompiliert“ und so zu dokumentieren.
* **Keine echten Geheimnisse im Code.** Keine API-Schlüssel, keine Client-Secrets. Der Admin trägt eigene Schlüssel zur Laufzeit ein; sie werden verschlüsselt gespeichert (Android Keystore / WebCrypto).
* **Das Admin-Passwort steht NIRGENDS im Klartext** (nicht im Code, nicht in Tests, Logs, Doku, Kommentaren). Nur Salt + PBKDF2-Hash (Konstanten unten). Tests benutzen das Test-Passwort `test-passwort-123` mit Test-Hash (unten). Ehrlicher Hinweis in der Doku: Ein clientseitiges Passwort ist eine Bequemlichkeits-Sperre, **kein** Schutz gegen jemanden, der die App-Dateien verändert.
* **Keine urheberrechtlich geschützten Bilder/Logos/Marken-Assets.** Hintergründe und JARVIS-Oberfläche sind eigene, generische Sci-Fi-Gestaltung (Ringe, Bögen, Gitter, Verläufe), per Code gezeichnet. Kein Marvel-/Film-Logo, kein Nachbau eines Film-Reaktors.
* **Dependency-Wächter:** `verifyNoForbiddenDependencies` verbietet Google-Play-Services, Firebase, ML Kit, Sentry usw. Keine solchen Abhängigkeiten einführen. Erlaubt neu: CameraX 1.4.2 (`androidx.camera:camera-core/camera2/lifecycle/view`).
* Compose-/Android-Code **konservativ** schreiben (nur APIs, die man sicher kennt, die im Projekt schon benutzt werden, oder stabile AndroidX-APIs). Lieber 20 Zeilen mehr als eine unsichere API. Jede Datei: Imports vollständig prüfen (häufigste Fehlerquelle ohne Compiler).
* UI-Texte **Deutsch**. Code-Kommentare Deutsch oder Englisch (im Projekt gemischt).
* Bestehende Funktionen (Browser, Tabs, VPN, Lesezeichen, Verlauf, lokales llama.cpp) dürfen **nicht kaputtgehen**.
* `JARVIS` bleibt der Name der Funktion (so heißt sie im Projekt des Nutzers).

## Aufgabenteilung (Dateibesitz – nur eigene Dateien ändern!)

| Teil | Besitzer | Pakete / Dateien |
|---|---|---|
| Web-App | Hauptagent | `web/**` |
| **Android A** (Kern) | Fork „android-a“ | `data/AppSettings.kt`, `data/SecretStore.kt`, `data/AccountStore.kt`, `auth/**`, `security/**`, `storage/**`, `ui/theme/**`, `ui/settings/**`, `ui/AppNavigation.kt`, `ui/BrowserScreen.kt`, `ui/BrowserDialogs.kt`, `ui/ListScreens.kt`, `ui/TabsScreen.kt`, `browser/**`, `data/BrowserStore.kt`, `data/Models.kt`, `MainActivity.kt`, `SecureBrowseApp.kt`, `AndroidManifest.xml`, `res/**`, `build.gradle*`, `gradle/libs.versions.toml`, `gradle.properties`, `proguard-rules.pro`, Tests unter `app/src/test/**/security`, `…/storage` |
| **Android B** (JARVIS) | Fork „android-b“ | `jarvis/**` (inkl. `JarvisCore.kt`, `JarvisModelManager.kt`, `LlamaInferenceEngine.kt` nur falls nötig), `ui/JarvisScreen.kt`, `ui/jarvis/**`, Tests unter `app/src/test/**/jarvis` |

`app/src/test/java/de/deinname/securebrowse/testvectors/Vectors.kt` wird **generiert**: `python3 tools/gen_kotlin_vectors.py` (aus `tests/vectors/*.json`). Nicht von Hand ändern.

Wer eine fremde Datei ändern müsste: **nicht ändern**, stattdessen im Abschlussbericht unter „Wünsche an den anderen Teil“ notieren.

## Verträge zwischen A und B (exakte Signaturen)

Basis-Paket: `de.deinname.securebrowse`.

### Von A bereitgestellt

```kotlin
// data/SecretStore.kt – verschlüsselte benannte Geheimnisse (AES-GCM, Android Keystore, wie EncryptedVpnProfileStore)
class SecretStore(context: Context) {
    fun get(name: String): String?
    fun put(name: String, value: String?)   // null/leer löscht
    fun has(name: String): Boolean
    fun clearAll()
}
// bekannte Namen: "cloud_api_key", "cloud_base_url_override" (optional), "apple_services_id"

// security/ContentSafety.kt + security/ThreatScanner.kt  (REINES Kotlin, keine android.*-Imports)
data class SafetyVerdict(val blocked: Boolean, val category: String?, val message: String)   // category: "weapons" | "drugs" | null
object ContentSafety { fun check(text: String): SafetyVerdict }

enum class ThreatLevel { CLEAN, SUSPICIOUS, MALICIOUS }
data class ScanResult(val level: ThreatLevel, val findings: List<String>)   // findings = stabile Codes (siehe Vektoren)
object ThreatScanner {
    fun scanUrl(url: String): ScanResult
    fun scanText(text: String): ScanResult
    fun scanFile(name: String, bytes: ByteArray): ScanResult
    fun describe(code: String): String        // deutsche Erklärung zu einem Code
}

// data/AppSettings.kt
data class AppSettings(
    val accentId: String = "jarvis",          // jarvis|cyan|green|yellow|orange|red|pink|purple|silver
    val backgroundId: String = "grid",        // grid|aurora|nebula|stars|sunset|ocean|rain|plain|custom
    val customBackgroundUri: String? = null,
    val themeMode: String = "auto",           // auto|light|dark  (übernimmt/ersetzt BrowserStore.themeMode)
    val reduceEffects: Boolean = false,       // Sparmodus: weniger Animation
    val incognitoDefault: Boolean = false,
    val scanFiles: Boolean = true, val scanLinks: Boolean = true, val scanPromptInjection: Boolean = true,
    val cacheMode: String = "default",        // default|small|none
    val maxCacheMb: Int = 100,
    val clearOnExitHistory: Boolean = false, val clearOnExitCache: Boolean = false, val clearOnExitChats: Boolean = false,
    val adminUnlocked: Boolean = false        // Schalter nach 10× Tippen sichtbar
)
class AppSettingsStore(context: Context) { val state: StateFlow<AppSettings>; fun update(block: (AppSettings) -> AppSettings) }

// Host-Implementierung für JARVIS-Aktionen (A implementiert, in AppNavigation/Container)
// (Interface selbst wird von B definiert, siehe unten)
```

### Von B bereitgestellt

```kotlin
// jarvis/JarvisHost.kt
interface JarvisHost {
    fun openUrl(url: String)           // im aktuellen Tab öffnen, zurück zum Browser
    fun search(query: String)          // Suchmaschine des Nutzers
    fun setAccent(id: String)          // Akzentfarbe (ids siehe AppSettings)
    fun setThemeMode(mode: String)     // "auto"|"light"|"dark"
    fun setIncognito(on: Boolean)
    fun openSettings()
    fun clearCache()
    fun clearHistory()
    fun userName(): String?            // Anzeigename des angemeldeten Kontos oder null
}

// ui/JarvisScreen.kt  (Route "jarvis" bleibt)
@Composable fun JarvisScreen(controller: JarvisController, host: JarvisHost, secrets: SecretStore, onBack: () -> Unit)

// ui/jarvis/JarvisSettingsSection.kt – wird von A in die Einstellungen unter der Überschrift „JARVIS“ eingebettet (innerhalb einer Column, nicht scrollbar!)
@Composable fun JarvisSettingsSection(controller: JarvisController, secrets: SecretStore)

// jarvis/JarvisCore.kt: JarvisController(context: Context) bleibt mit unveränderter Konstruktor-Signatur
// (B darf Felder ergänzen: prefs, voice, speech, brain …)
```

JARVIS-HUD nutzt `MaterialTheme.colorScheme.primary` als Leuchtfarbe → Akzentwechsel färbt die HUD mit (Standard Jarvis-Blau).
A garantiert: `colorScheme.primary` = gewählter Akzent (hell/dunkel jeweils passend), `colorScheme.background` bleibt dunkel genug (im Dunkelmodus), A zeichnet den Hintergrund **hinter** der App (`AppBackground`), Flächen der App sind halbtransparent, damit er sichtbar bleibt.

## Konstanten

**Akzente** (id → Name, dunkel-primary / hell-primary):
jarvis → „Jarvis-Blau“ #4CC3FF / #0072B8 · cyan → „Türkis“ #3DE0E0 / #00838A · green → „Grün“ #5BE08A / #1B7F3E · yellow → „Gelb“ #FFD84D / #8A6D00 · orange → „Orange“ #FFA14D / #B25000 · red → „Rot“ #FF6B6B / #B3261E · pink → „Pink“ #FF6FB5 / #B80F6A · purple → „Lila“ #B48CFF / #6B3FD0 · silver → „Silber“ #D0D7E2 / #4A5568.

**Hintergründe** (alle selbst gezeichnet): grid „Holo-Gitter“ (Standard) · aurora „Nordlicht“ · nebula „Nebel“ · stars „Sternenhimmel“ · sunset „Sonnenuntergang“ · ocean „Ozean“ · rain „Daten-Regen“ · plain „Einfarbig“ · custom „Eigenes Bild“ (Foto aus der Galerie per Dateiauswahl, Abdunklung wählbar).

**Stimmen:** gender `male|female|neutral` (Standard `male`), Rate 0.5–2.0 (1.0), Tonhöhe 0.5–1.5 (1.0). Android liefert kein offizielles Geschlecht: `VoiceHeuristics.classify(name)` rät anhand bekannter Namen (Vektoren in `tests/vectors/voice.json`), sonst Tonhöhe verschieben (male ≈ 0.82, female ≈ 1.12, neutral 1.0). Zusätzlich Liste aller installierten Stimmen zur manuellen Auswahl.

**Admin-Passwort-Prüfung** (PBKDF2-HMAC-SHA256, 32 Byte, 120000 Iterationen):
* SALT_HEX = `5b0c9e47d3a1f26e8c40b97a12de6f35`
* ADMIN_HASH_HEX = `d9ce423d9e97e14e686dfd1751e0d6d93ac46534e79806174fed3a22aa41e70a`
* Test-Passwort `test-passwort-123` → Hash `3e3ae55b2f978b9eafc36969f02c5b8acab97b7137f519b8136bc3de6eba3760` (gleiches Salt)
* Vergleich in konstanter Zeit; nach 5 Fehlversuchen Sperre 60 s, danach verdoppelt (max. 15 min); Zähler in Speicher.
* Admin kann das Passwort ändern → neuer Salt+Hash wird (verschlüsselt/gehasht) gespeichert und hat Vorrang vor der Konstante.

**Entsperr-Ablauf:** Einstellungen → „Info“ → Zeile „Version“ → 10× tippen (ab dem 4. Tipp Hinweis „Noch n Schritte …“) → Schalter „Admin-Modus“ erscheint in der Einstellungsliste (persistent: `adminUnlocked`) → Schalter antippen → Passwort-Dialog → richtig: Admin-Bereich öffnet; falsch: Fehlermeldung + Zähler/Sperre. Admin-Sitzung sperrt sich automatisch nach Verlassen des Bereichs.

**Admin-Bereich** enthält: KI-API (Anbieter `anthropic` | `openai_compat`, Modellname, optionale Basis-URL, API-Schlüssel – verschlüsselt, maskiert anzeigbar), OAuth-Hinweise/IDs (Google/Apple), Schutz-Strenge, Diagnose (Fähigkeiten des Geräts), Konten-Verwaltung (lokale Konten ansehen/löschen), Passwort ändern, „Alle Daten zurücksetzen“, „Admin sperren“.

## Funktions-Details

### Android A
1. **Theme** (`ui/theme`): 9 Akzente × hell/dunkel; `SecureBrowseTheme(darkTheme, accentId, …)`; `AppBackground(backgroundId, customUri, reduceEffects, dark)` als Compose-Canvas-Zeichnung (Gitter in Perspektive, Verläufe, Sterne, Wellen, fallender Code) – ohne Bitmap-Assets; eigenes Foto per `ImageDecoder`/`BitmapFactory` (kleinrechnen!). MainActivity setzt Theme + Hintergrund.
2. **Einstellungen als Vollbild-Screen** (Route `settings`; ersetzt das Bottom-Sheet im BrowserScreen): Abschnitte *Konto · Darstellung (Modus, Akzent, Hintergrund, Sparmodus, Töne/Leuchten) · JARVIS (`JarvisSettingsSection`) · Sicherheit (Inhaltsschutz = immer an, nur Anzeige; Datei-/Link-/Prompt-Injection-Scan Schalter; HTTPS-Hinweise; gemischte Inhalte) · Datenschutz & Speicher (Inkognito Standard, Cache-Modus + Größenlimit, Speicherübersicht je Bereich, einzelne Löschen-Schaltflächen, Beim-Beenden-Löschen, Verlauf/Lesezeichen) · Browser (Suchmaschine, Desktop-Modus) · Info (Name, Version, Build, Paket, Gerät, Lizenzen: WireGuard Apache-2.0, llama.cpp MIT, AndroidX Apache-2.0, OpenVPN/ics GPLv2 falls eingebunden; „Was ist neu 2.0“; 10×-Tippen auf Version) · [Admin-Schalter, wenn freigeschaltet].* Keine Funktion aus dem alten Sheet verlieren.
3. **Konto:** lokale Konten (E-Mail + Passwort, PBKDF2-HMAC-SHA256 mit eigenem Salt je Konto, 150000 Iterationen, in `SecretStore`/verschlüsselt), Registrieren (Name, E-Mail-Format-Prüfung, Passwort ≥ 8 Zeichen + Stärkeanzeige, Wiederholung), Anmelden, Abmelden, Name ändern, Konto löschen, „Passwort vergessen“ ehrlich: ohne Server nicht möglich → erklärt Konto-Zurücksetzen. **Google:** OAuth 2.0 Code-Flow + PKCE über Browser-Intent (kein Play-Services!), Redirect-Schema aus Gradle-Property `securebrowse.googleClientId` (leer = „nicht eingerichtet“ → Dialog mit Einrichtungsschritten), Token-Tausch per `HttpsURLConnection` auf `https://oauth2.googleapis.com/token`, ID-Token-Nutzlast (email, name) lesen. **Apple:** Schaltfläche vorhanden, erklärt ehrlich, dass „Sign in with Apple“ auf Android einen Apple-Developer-Account + kleinen Server braucht (nicht eingerichtet). Alle drei Wege führen zu einem lokalen Profil (`Account(provider, email, name)`).
4. **Sicherheit:** `ContentSafety` und `ThreatScanner` als **Port** der JS-Referenz (`web/src/js/10-safety.js`, `11-threat.js`) mit denselben Datentabellen und demselben Algorithmus; Tests gegen `Vectors` (Safety, URLs, Texte, Dateien) – kompiliert/ausgeführt mit `scratchpad/tools/kc.sh`. `AdminGate` (reines Kotlin): PBKDF2-Prüfung, Lockout-Logik (Zeit injizierbar), Tests mit Test-Passwort. Link-Scan im Browser: vor dem Laden einer von JARVIS/Nutzer eingegebenen Adresse `scanUrl`; „malicious“ blockieren (Dialog), „suspicious“ warnen.
5. **Inkognito:** `TabUi.incognito`, Menü „Neuer Inkognito-Tab“ (Tab-Leiste: dunkle Chips mit Maske-Symbol), kein Verlauf, Tab-URLs nicht persistiert, `WebSettings.cacheMode = LOAD_NO_CACHE`, `FLAG_SECURE` solange ein Inkognito-Tab sichtbar ist (Schalter „Bildschirmaufnahmen in Inkognito sperren“), beim Schließen des letzten Inkognito-Tabs: `CookieManager.removeAllCookies`, `WebStorage.deleteAllData`, `WebView.clearCache/clearFormData/clearHistory`. **Ehrlicher Hinweis in UI+Doku:** WebView teilt den Cookie-Speicher prozessweit – das Löschen betrifft auch normale Tabs.
6. **Speicher/Cache:** `StorageManager`: Größen (App-Cache, WebView-Daten, JARVIS-Modelle, Datenbanken/DataStore), Löschfunktionen je Bereich, Cache-Modus (default → `LOAD_DEFAULT`, none → `LOAD_NO_CACHE`, small → default + Bereinigung beim Start wenn > Limit), Beim-Beenden-Löschen in `MainActivity.onStop/onDestroy` (nur wenn Nutzer es aktiviert hat). Formatierung deutsch („12,5 MB“).
7. Verdrahtung: `AppContainer` erhält `settingsStore`, `secretStore`, `accountStore`, `storageManager`; `AppNavigation` bekommt Route `settings` (und Unter-Routen/Dialoge für Konto, Admin); `AppJarvisHost` implementiert `JarvisHost`. `build.gradle.kts`: CameraX-Abhängigkeiten + `versionName = "2.0.0"`, `versionCode = 2`, Manifest-Platzhalter für Google-Redirect. `AndroidManifest.xml`: `<queries>` für TTS (`android.intent.action.TTS_SERVICE`) und Spracherkennung (`android.speech.RecognitionService`), Intent-Filter für Google-Redirect in `MainActivity`; CAMERA/RECORD_AUDIO bleiben (Laufzeit-Abfrage durch JARVIS selbst, nicht beim Start).

### Android B
1. **HUD** (`ui/jarvis/JarvisHud.kt`): Compose-`Canvas`, Leuchtfarbe = `colorScheme.primary`. Kern-Orb mit Leuchten, 4–5 rotierende segmentierte Ringe, Tick-Ring, Radar-Bogen, kreisförmige Pegelbalken (Mikrofonpegel/Sprechpegel), Ecken-Klammern; Zustände *Bereit · Hört zu · Denkt nach · Spricht · Aus*. `reduceEffects`/Sparmodus → weniger Animation. Animation pausiert, wenn Screen nicht sichtbar (Lifecycle) – geringer Ressourcenverbrauch ist dem Nutzer wichtig. Seitenpanels mit **echten** Daten (Uhrzeit, Datum, Akku, Netz an/aus, Mikro/Kamera-Status, Schutzstatus, Modellstatus) – keine erfundenen Telemetriewerte.
2. **Layout** (`JarvisScreen`): HUD oben, darunter Transkript (Chat als HUD-Panel), Eingabezeile mit Text, Mikro-Taste, Kamera-Taste, Senden/Stopp; Schnellbefehle als Chips („Uhrzeit“, „Timer 5 Min“, „Farbe Pink“ …); „Lokales Modell“ (bestehende GGUF-Verwaltung) als einklappbarer Bereich – **bestehende Funktion bleibt**.
3. **Mikrofon:** `SpeechInput` (android.speech.SpeechRecognizer, Sprache de-DE, Partial-Results, `onRmsChanged` → Pegel). Laufzeit-Permission `RECORD_AUDIO` erst beim ersten Druck auf die Mikro-Taste, mit Erklärtext; fehlt ein Erkennungsdienst (`isRecognitionAvailable == false`) → klare Meldung.
4. **Stimme:** `VoiceOutput` (TextToSpeech): Stimmenliste, Auswahl nach Geschlechts-Heuristik oder manuell, Rate/Tonhöhe, Test-Satz, `speakReplies`-Schalter, „Stopp“; Sprechzustand für HUD; Markdown/URLs/Emoji vor dem Sprechen bereinigen. Einstellungen in `JarvisPrefs` (SharedPreferences `jarvis_settings`, vorhandene Datei weiterverwenden) + `JarvisSettingsSection` (Stimme männlich/weiblich/neutral, Stimmenliste, Geschwindigkeit, Tonhöhe, Test, Antworten vorlesen, KI-Motor Automatisch/Lokal/Cloud, Chats speichern, Chat löschen).
5. **Kamera:** `CameraPanel` mit CameraX (`PreviewView` in `AndroidView`, `ImageCapture`), Laufzeit-Permission `CAMERA` erst beim Öffnen, Kamerawechsel (vorn/hinten), HUD-Overlay (Rahmen, Scanlinie – nur Optik), Foto aufnehmen. **Ehrlich:** ohne Vision-fähige Cloud-KI kann JARVIS das Bild nicht beschreiben → Meldung. Mit Cloud-KI: vor dem **ersten** Senden eines Fotos Einwilligungsdialog („Das Bild wird an <Anbieter> gesendet“); Foto auf ≤ 1024 px und JPEG q≈80 verkleinern.
6. **Gehirn** (`JarvisBrain`): Eingabe → `ContentSafety.check` (blockiert → freundliche Ablehnung, kein Modellaufruf) → optional `ThreatScanner.scanText` (Prompt-Injection → Warnhinweis, Eingabe wird trotzdem entschärft behandelt) → `SkillRouter.route` (lokale Befehle; Aktionen über `JarvisHost`) → sonst Motor: Cloud (wenn gewählt/automatisch und Schlüssel vorhanden), sonst lokales llama.cpp (wenn geladen), sonst Hilfetext („Dafür brauche ich ein KI-Modell …“). Ausgabe nochmals durch `ContentSafety.check` (blockiert → Ersatzantwort). Systemprompt (Deutsch, kurz, höflich, Sicherheitsregeln zu Waffen/Drogen, keine Medizin-/Rechtsberatung als Gewissheit).
7. **CloudEngine:** `HttpsURLConnection` (nur HTTPS), Anbieter `anthropic` (`POST https://api.anthropic.com/v1/messages`, Header `x-api-key`, `anthropic-version: 2023-06-01`, Standardmodell `claude-haiku-5-5`) und `openai_compat` (`POST {basis}/chat/completions`, `Authorization: Bearer`), Bild als Base64-Block, Zeitlimit 60 s, Abbruch (Coroutine-Cancel schließt Verbindung), Fehlermeldungen verständlich (401 → „Schlüssel ungültig“, 429 …), Schlüssel nur aus `SecretStore`, nie loggen.
8. **SkillRouter / VoiceHeuristics:** reines Kotlin, **Port** der JS-Referenz (`web/src/js/12-skills.js`, `13-voice.js`), Tests gegen `Vectors.skills` / `Vectors.voices` – kompiliert und ausgeführt mit `kc.sh`.

## Verifikation / Abschluss

* Reine Logik: kompilieren + Vektor-Tests ausführen (Skript `scratchpad/tools/kc.sh <out> <dateien…>`; Kotlin 2.0.21, nur JDK + kotlin-stdlib).
* Alles andere: sorgfältig selbst lesen („Compiler im Kopf“): Imports, Nullability, `@Composable`-Kontexte, Lambda-Typen, Namenskollisionen, `remember`/`State`-Regeln, Berechtigungen.
* Abschlussbericht (kurz, ehrlich): erstellte/geänderte Dateien, was kompiliert+getestet wurde (mit Ergebnis), was nicht, bekannte Risiken, Wünsche an den anderen Teil.
* Zusätzlich je Teil eine Doku-Datei: `docs/ANDROID_A.md` bzw. `docs/ANDROID_B.md` (Funktionen, Bedienung, Grenzen, offene PRUEFEN-Punkte).
