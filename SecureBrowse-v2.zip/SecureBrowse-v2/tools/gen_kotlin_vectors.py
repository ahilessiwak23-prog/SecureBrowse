#!/usr/bin/env python3
"""Erzeugt aus tests/vectors/*.json eine Kotlin-Datei mit denselben Testfällen.

Aufruf:  python3 tools/gen_kotlin_vectors.py <ausgabe.kt>
Standard: app/src/test/java/de/deinname/securebrowse/testvectors/Vectors.kt
Die JSON-Dateien sind die einzige Quelle der Wahrheit (JS und Kotlin testen dagegen).
"""
import json, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VEC = os.path.join(ROOT, "tests", "vectors")
DEFAULT_OUT = os.path.join(ROOT, "app", "src", "test", "java", "de", "deinname", "securebrowse", "testvectors", "Vectors.kt")


def k(s):
    """Kotlin-String-Literal (ASCII-only, alles Kritische escaped)."""
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '\\': out.append('\\\\')
        elif ch == '"': out.append('\\"')
        elif ch == '$': out.append('\\$')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('\\r')
        elif ch == '\t': out.append('\\t')
        elif 32 <= o < 127: out.append(ch)
        elif o > 0xFFFF:
            o -= 0x10000
            out.append('\\u%04x\\u%04x' % (0xD800 + (o >> 10), 0xDC00 + (o & 0x3FF)))
        else: out.append('\\u%04x' % o)
    out.append('"')
    return ''.join(out)


def load(name):
    with open(os.path.join(VEC, name), encoding="utf-8") as f:
        return json.load(f)


def klist(items):
    return "listOf(" + ", ".join(k(x) for x in items) + ")"


def main():
    out_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT
    safety, threat, skills, voice = load("safety.json"), load("threat.json"), load("skills.json"), load("voice.json")
    L = []
    w = L.append
    w("// GENERIERT von tools/gen_kotlin_vectors.py aus tests/vectors/*.json – nicht von Hand ändern.")
    w("package de.deinname.securebrowse.testvectors")
    w("")
    w("class SafetyCase(val text: String, val expect: String, val category: String?)")
    w("class UrlCase(val url: String, val level: String, val codes: List<String>)")
    w("class TextCase(val text: String, val level: String, val codes: List<String>)")
    w("class FileCase(val name: String, val bytes: ByteArray, val level: String, val codes: List<String>)")
    w("class SkillCase(val text: String, val handled: Boolean, val actionType: String?, val actionArgs: Map<String, String>, val contains: List<String>)")
    w("class VoiceCase(val name: String, val expect: String)")
    w("")
    w("object Vectors {")
    w("    private fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }")
    w("")
    c = skills["ctx"]
    w("    const val CTX_YEAR = %d; const val CTX_MONTH = %d; const val CTX_DAY = %d" % (c["year"], c["month"], c["day"]))
    w("    const val CTX_WEEKDAY = %d; const val CTX_HOUR = %d; const val CTX_MINUTE = %d" % (c["weekday"], c["hour"], c["minute"]))
    w("    val accents: List<String> = " + klist(skills["accents"]))
    w("")
    w("    val safety: List<SafetyCase> = listOf(")
    for x in safety["cases"]:
        w("        SafetyCase(%s, %s, %s)," % (k(x["text"]), k(x["expect"]), k(x["category"]) if x.get("category") else "null"))
    w("    )")
    w("")
    w("    val urls: List<UrlCase> = listOf(")
    for x in threat["urls"]:
        w("        UrlCase(%s, %s, %s)," % (k(x["url"]), k(x["level"]), klist(x["codes"])))
    w("    )")
    w("")
    w("    val texts: List<TextCase> = listOf(")
    for x in threat["texts"]:
        w("        TextCase(%s, %s, %s)," % (k(x["text"]), k(x["level"]), klist(x["codes"])))
    w("    )")
    w("")
    w("    val files: List<FileCase> = listOf(")
    for x in threat["files"]:
        raw = bytes.fromhex(x["hex"]) if "hex" in x else x["text"].encode("utf-8")
        if "append_text" in x:
            raw += x["append_text"].encode("utf-8")
        w("        FileCase(%s, hex(%s), %s, %s)," % (k(x["name"]), k(raw.hex()), k(x["level"]), klist(x["codes"])))
    w("    )")
    w("")
    w("    val skills: List<SkillCase> = listOf(")
    for x in skills["cases"]:
        a = x.get("action")
        if x["handled"] and a:
            t = k(a["type"])
            args = ", ".join("%s to %s" % (k(kk), k(str(json.dumps(v)) if isinstance(v, bool) else str(v)))
                             for kk, v in a.items() if kk != "type")
            amap = "mapOf(%s)" % args if args else "emptyMap()"
        else:
            t, amap = "null", "emptyMap()"
        w("        SkillCase(%s, %s, %s, %s, %s)," % (k(x["text"]), "true" if x["handled"] else "false", t, amap, klist(x.get("contains", []))))
    w("    )")
    w("")
    w("    val voices: List<VoiceCase> = listOf(")
    for x in voice["cases"]:
        w("        VoiceCase(%s, %s)," % (k(x["name"]), k(x["expect"])))
    w("    )")
    w("}")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("geschrieben:", out_path)


if __name__ == "__main__":
    main()
