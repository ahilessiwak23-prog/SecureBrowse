# JARVIS-Steuerung in SecureBrowse

- Das vorhandene SecureBrowse-Browserdesign und die Browsernavigation bleiben erhalten.
- JARVIS wird nicht automatisch beim Start geöffnet.
- JARVIS wird nur geöffnet, wenn der Nutzer den JARVIS-Eintrag in der unteren Navigation antippt.
- JARVIS lässt sich zusätzlich im Einstellungsbereich des Browsers ein- und ausschalten.
- Die Einstellung wird dauerhaft in `SharedPreferences` gespeichert.
- Die JARVIS-Seite besitzt weiterhin ihren eigenen Ein-/Ausschalter.
- Beim Zurückkehren in den Browser wird der gespeicherte Status erneut eingelesen.

Hinweis: Diese Änderung ergänzt die Bedienung. Sie implementiert noch keine llama.cpp-Inferenz.
