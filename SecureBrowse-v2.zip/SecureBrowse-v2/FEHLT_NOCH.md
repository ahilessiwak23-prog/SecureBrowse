# FEHLT NOCH – SecureBrowse / JARVIS

Stand: 21.11.2026. Diese Liste ist eine ehrliche Checkliste. Nicht angekreuzte Punkte sind nicht als erledigt nachgewiesen.

## Umgebung / Build
- [ ] Netzwerkzugriff zu Gradle, Google Maven, Maven Central und GitHub verfügbar
- [ ] JDK 17+ installiert (hier zuvor JDK 21 erkannt)
- [ ] Android SDK installiert, Plattform/Build Tools passend zum Projekt
- [ ] Android NDK und CMake installiert
- [ ] Gradle Wrapper erzeugt: `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`
- [ ] Wrapper-Distribution SHA-256 gesetzt und überprüft
- [ ] `./gradlew :app:testDebugUnitTest :app:assembleDebug --stacktrace` erfolgreich
- [ ] Dependency-Guard: `./gradlew :app:verifyNoForbiddenDependencies` erfolgreich
- [ ] Alle als PRUEFEN markierten Versionsangaben anhand offizieller Quellen verifiziert

## llama.cpp / Native
- [ ] llama.cpp stabilen Tag/Commit anhand offizieller Release-/Git-Daten verifizieren und pinnen
- [ ] `tools/add-llama-cpp.sh <tag>` erfolgreich ausgeführt
- [ ] JNI-Datei gegen echte gepinnte `llama.h` geprüft und ggf. angepasst
- [ ] CMake-Optionen und Gradle-Argumente gegen gepinnte llama.cpp-Version validiert
- [ ] NDK-Build nur arm64-v8a; `-march=armv8.2-a+dotprod` (kein armv8.7a)
- [ ] ggml Debug-Build weiterhin mit `-O3`
- [ ] Native Kompilierung erfolgreich
- [ ] UTF-8 byte[]-Übertragung bleibt erhalten; Modelltext nicht via `NewStringUTF`
- [ ] JNI-Aufrufe auf einem Thread; Cancel lock-frei
- [ ] Native Tests gegen echte native Bibliothek ausgeführt/erweitert

## APK / Packaging
- [ ] `libjarvis_llama.so` im APK nachgewiesen
- [ ] APK ELF-/Native-Library 16-KB-Alignment geprüft
- [ ] Debug APK installiert und startet
- [ ] Release-Build mit R8/Minify getestet
- [ ] ProGuard-Regeln für LlamaBridge und TokenCallback geprüft

## JARVIS / Gerätetest (ADB)
- [ ] Gerät arm64-v8a erreichbar; ADB-Ausgabe dokumentiert
- [ ] GGUF Modell (ca. 1B Q4) importiert
- [ ] Modell laden, Prompt senden und echte Modellantwort bestätigen
- [ ] Stopp während Generierung testen
- [ ] Entladen testen
- [ ] Zu großes Modell durch MemoryGuard ablehnen
- [ ] Freier RAM / 60%-RAM-Limit / KV-Budget geprüft
- [ ] Low-memory-Prüfung während Antwort getestet
- [ ] `onTrimMemory` / `onLowMemory` Verhalten geprüft
- [ ] Zeit- und Tokenlimit geprüft
- [ ] Hintergrundverhalten / Prozessbeendigung dokumentiert

## CI
- [ ] GitHub Actions Workflow tatsächlich ausgeführt
- [ ] Build- und Unit-Test-Logs gesichert
- [ ] APK-Artifact aus CI heruntergeladen und geprüft

## Bekannte Grenzen
- Ohne Foreground-Service kann Android die App im Hintergrund beenden; Antwort kann beim Verlassen des JARVIS-Screens stoppen.
- KV-Cache-Schätzung basiert auf f16/Standard-Transformer und kann bei SWA/Hybrid/Mamba abweichen.
- Der gesamte Verlauf wird pro Antwort neu ausgewertet; lange Chats können langsam werden.
- Chat-Speicherung, Spracheingabe/-ausgabe, Vision und Web-Recherche sind nicht implementiert/nicht bestätigt.
- Galaxy A53: niedrige Token-Raten erwartet, noch nicht gemessen.
- Native Bibliothek nur arm64-v8a; x86-Emulator meldet fehlende native Bibliothek.

## Bisher belegte Ergebnisse
- Host UTF-8-Test: zuvor als bestanden dokumentiert; nicht als Android-/JNI-Test interpretieren.
- Shell-Syntax und YAML-Syntax: zuvor als geprüft dokumentiert.
- Wrapper und llama.cpp Bootstrap scheiterten in der vorigen Umgebung an DNS/Netzwerkzugriff.
- Kein APK-/Geräte-/Release-/CI-Nachweis vorhanden.

## Ergänzung nach URL-Validierungsverbesserung (21.11.2026)
- [x] Explizite HTTP(S)-URL-Prüfung auf URI-Basis statt manueller Authority-Aufteilung ergänzt.
- [x] Tests für malformed URLs und IPv6-URL mit Port ergänzt (Tests noch nicht ausgeführt).

## OpenVPN (eingebettet, unabhängig von anderen Apps)
- [x] `VpnBackend`-Schnittstelle, Profil-Typ im verschlüsselten Store, gemeinsame VPN-Oberfläche (.conf / .ovpn)
- [x] `.ovpn`-Prüfung: Skript-Direktiven (up/down/plugin/…) und externe Dateien werden abgelehnt; Unit-Tests ergänzt (nicht ausgeführt)
- [ ] `tools/add-openvpn.sh <tag>` ausführen (Netzwerk nötig), Tag anhand offizieller Tags pinnen
- [ ] `OpenVpnEngineImpl.kt` gegen die gepinnte ics-openvpn-Version prüfen (API aus dem Gedächtnis geschrieben)
- [ ] Gradle-Einbindung des ics-Moduls (Flavor, `FAIL_ON_PROJECT_REPOS`, NDK/openssl-Submodule) im Build prüfen
- [ ] GPLv2-Folge für SecureBrowse entscheiden; Dependency-Guard mit ics-Modul laufen lassen
- [ ] Gerätetest: Verbinden, Trennen, Profil wird nach dem Trennen aus ics-Speicher entfernt

## Nach der weiteren Validator-Härtung
- [ ] OpenVPN-Validator-Unit-Tests um unbekannte Inline-Blöcke, unerwartete Block-Enden und UTF-8-Byte-Limit ergänzen und ausführen
- [ ] Beispielprofile mit mehreren `<connection>`-Blöcken gegen die strengere Validierung prüfen
