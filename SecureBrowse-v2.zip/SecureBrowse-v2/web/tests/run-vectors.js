/* Führt die gemeinsamen Testfälle (tests/vectors/*.json) gegen die JS-Referenzmodule aus.
 * Aufruf:  node web/tests/run-vectors.js   (Exit-Code 1 bei Fehlern)
 */
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..', '..');
const vec = n => JSON.parse(fs.readFileSync(path.join(root, 'tests', 'vectors', n), 'utf8'));
const src = n => require(path.join(root, 'web', 'src', 'js', n));

const Safety = src('10-safety.js');
const Threat = src('11-threat.js');
const Skills = src('12-skills.js');
const Voice = src('13-voice.js');

let pass = 0, fail = 0;
function ok(cond, label, detail) {
  if (cond) { pass++; return; }
  fail++; console.log('FEHLER  ' + label + (detail ? '  ->  ' + detail : ''));
}

// --- Schutzfilter
for (const c of vec('safety.json').cases) {
  const v = Safety.check(c.text);
  const want = c.expect === 'block';
  ok(v.blocked === want && (!want || v.category === c.category), 'safety: ' + c.text,
    'erwartet ' + c.expect + (c.category ? '/' + c.category : '') + ', erhalten ' + (v.blocked ? 'block/' + v.category + '/' + v.rule : 'allow'));
}

// --- Scanner
const th = vec('threat.json');
function checkScan(label, r, c) {
  const missing = c.codes.filter(x => !r.findings.includes(x));
  ok(r.level === c.level && missing.length === 0, label, 'erwartet ' + c.level + ' ' + JSON.stringify(c.codes) + ', erhalten ' + r.level + ' ' + JSON.stringify(r.findings));
  if (c.level === 'clean') ok(r.findings.length === 0, label + ' (keine Befunde)', JSON.stringify(r.findings));
}
for (const c of th.urls) checkScan('url: ' + c.url, Threat.scanUrl(c.url), c);
for (const c of th.texts) checkScan('text: ' + c.text, Threat.scanText(c.text), c);
for (const c of th.files) {
  let bytes = c.hex ? Buffer.from(c.hex, 'hex') : Buffer.from(c.text, 'utf8');
  if (c.append_text) bytes = Buffer.concat([bytes, Buffer.from(c.append_text, 'utf8')]);
  checkScan('file: ' + c.name, Threat.scanFile(c.name, new Uint8Array(bytes)), c);
}

// --- Befehle
const sk = vec('skills.json');
for (const c of sk.cases) {
  const r = Skills.route(c.text, Object.assign({}, sk.ctx));
  ok(r.handled === c.handled, 'skill handled: ' + c.text, 'erwartet ' + c.handled + ', erhalten ' + r.handled + ' (' + r.reply + ')');
  if (!c.handled || r.handled !== c.handled) continue;
  ok(JSON.stringify(r.action) === JSON.stringify(c.action || null) || (r.action && c.action && deepEq(r.action, c.action)) || (!r.action && !c.action),
    'skill action: ' + c.text, 'erwartet ' + JSON.stringify(c.action) + ', erhalten ' + JSON.stringify(r.action));
  for (const s of (c.contains || [])) ok(r.reply.includes(s), 'skill reply: ' + c.text, '"' + s + '" fehlt in "' + r.reply + '"');
  if (!c.action) ok(r.reply.length > 0, 'skill reply nicht leer: ' + c.text);
}
function deepEq(a, b) {
  const ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
  return JSON.stringify(ka) === JSON.stringify(kb) && ka.every(k => a[k] === b[k]);
}
for (const a of sk.accents) ok(!!Skills.ACCENT_NAMES[a], 'accent name: ' + a);

// --- Stimmen
for (const c of vec('voice.json').cases) {
  const got = Voice.classify(c.name);
  ok(got === c.expect, 'voice: ' + c.name, 'erwartet ' + c.expect + ', erhalten ' + got);
}

console.log('\n' + pass + ' bestanden, ' + fail + ' fehlgeschlagen');
process.exit(fail ? 1 : 0);
