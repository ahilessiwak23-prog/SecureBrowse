import fs from 'fs';
const dir='src/js/';const mods=['10-safety.js','11-threat.js','12-skills.js','13-voice.js'].map(f=>fs.readFileSync(dir+f,'utf8')).join('\n');
const t=fs.readFileSync('src/app.html','utf8').split('/*MODULES*/').join(mods);fs.writeFileSync('securebrowse-jarvis.html',t);console.log('ok',t.length);
