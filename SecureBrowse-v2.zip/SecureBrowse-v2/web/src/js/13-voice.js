/* VoiceHeuristics – rät das Geschlecht einer TTS-Stimme anhand ihres Namens und wählt eine passende Stimme.
 * Ehrlich: Browser und Android liefern KEIN offizielles Geschlecht. Unbekannte Namen => 'unknown'
 * (dann verschiebt JARVIS die Tonhöhe, damit „männlich/weiblich“ trotzdem hörbar anders klingt).
 * Referenzimplementierung – die Kotlin-Version (jarvis/VoiceHeuristics.kt) ist ein 1:1-Port.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.VoiceHeuristics = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var FEMALE = ('katja amala anna petra helena marlene vicki hedda samantha karen moira zira susan linda hazel aria jenny sonia libby maisie ' +
    'emma amy salli joanna kendra kimberly ivy nicole tessa fiona veena victoria allison ava claudia birgit marie lena mia laura elena sabine ' +
    'ingrid nora hanna johanna ellen tina steffi yvonne katharina sophie clara lara female weiblich frau woman girl').split(' ');
  var MALE = ('conrad jonas markus yannick viktor martin alex daniel david mark george guy ryan hans stefan thomas fred ralph tom ' +
    'klaus jan peter paul felix max lukas tim michael andreas christian dirk florian kai jens sven killian bernd rolf male maennlich mann man boy').split(' ');

  function fold(s) {
    s = String(s).toLowerCase();
    s = s.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
    return s.normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  function classify(name) {
    var toks = fold(name).split(/[^a-z0-9]+/).filter(Boolean);
    var f = false, m = false;
    for (var i = 0; i < toks.length; i++) {
      if (FEMALE.indexOf(toks[i]) >= 0) f = true;
      if (MALE.indexOf(toks[i]) >= 0) m = true;
    }
    if (f && !m) return 'female';
    if (m && !f) return 'male';
    return 'unknown';
  }

  /* Wählt aus einer Stimmenliste ({name, lang, localService}) die beste für Sprache + Geschlecht. */
  function pickVoice(voices, gender, langPrefix) {
    var lp = (langPrefix || 'de').toLowerCase();
    var cand = voices.filter(function (v) { return String(v.lang || '').toLowerCase().indexOf(lp) === 0; });
    if (!cand.length) cand = voices.slice();
    function score(v) {
      var s = 0, c = classify(v.name);
      if (gender !== 'neutral' && c === gender) s += 10;
      if (gender === 'neutral' && c === 'unknown') s += 4;
      if (/natural|neural|online|premium|enhanced/i.test(v.name)) s += 3;
      if (v.localService) s += 1;
      return s;
    }
    var best = null, bs = -1;
    cand.forEach(function (v) { var s = score(v); if (s > bs) { bs = s; best = v; } });
    return best;
  }

  /* Tonhöhe: passt die gewählte Stimme zum Wunsch-Geschlecht, bleibt sie unverändert; sonst wird verschoben. */
  function pitchFor(gender, voiceName, basePitch) {
    var base = typeof basePitch === 'number' ? basePitch : 1;
    var c = voiceName ? classify(voiceName) : 'unknown';
    if (gender === 'neutral' || c === gender) return base;
    var shifted = gender === 'male' ? 0.82 : 1.12;
    return Math.max(0.5, Math.min(1.5, base * shifted));
  }

  return { classify: classify, pickVoice: pickVoice, pitchFor: pitchFor };
});
