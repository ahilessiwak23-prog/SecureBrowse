/* ThreatScanner – "Virenschutz" für die KI-Eingaben: Links, Texte, Dateien.
 *
 * Ehrlich: Das ist KEIN Ersatz für ein echtes Antivirenprogramm. Er erkennt typische Warnzeichen
 * (Testsignatur EICAR, ausführbare Dateien, getarnte Dateiendungen, Download-&-Ausführen-Muster,
 * Skripte, Phishing-Link-Tricks, Prompt-Injection). Er liest Dateien nur als Bytes und führt nie etwas aus.
 * Referenzimplementierung – die Kotlin-Version (security/ThreatScanner.kt) ist ein 1:1-Port.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ThreatScanner = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MAL = 'malicious', SUS = 'suspicious', CLEAN = 'clean';

  var DESCRIPTIONS = {
    dangerous_scheme: 'Dieser Link-Typ kann Code ausführen oder lokale Dateien lesen und wird blockiert.',
    userinfo: 'Die Adresse enthält „Name@“ vor dem Servernamen – ein typischer Trick, um eine falsche Seite echt aussehen zu lassen.',
    ip_host: 'Die Adresse nutzt eine reine IP-Adresse statt eines Namens.',
    punycode: 'Der Servername enthält Sonderzeichen-Kodierung (xn--), die oft für täuschend ähnliche Adressen benutzt wird.',
    brand_spoof: 'Der Servername enthält einen bekannten Markennamen, gehört aber nicht zur echten Seite dieser Marke.',
    shortener: 'Verkürzter Link – das echte Ziel ist nicht sichtbar.',
    deep_subdomain: 'Ungewöhnlich viele Unterdomains – häufig bei Phishing-Seiten.',
    invalid: 'Das ist keine gültige Webadresse.',
    eicar: 'Enthält die EICAR-Virentestsignatur (ein harmloser Test, den Virenscanner als Virus melden).',
    executable: 'Ausführbare Datei (Programm). Die KI öffnet oder startet so etwas nicht.',
    double_extension: 'Doppelte Dateiendung (z. B. „.pdf.exe“) – klassische Tarnung für Schadprogramme.',
    magic_mismatch: 'Dateiinhalt passt nicht zur Dateiendung: Ein Programm tarnt sich als harmlose Datei.',
    dangerous_extension: 'Gefährliche Dateiendung (Programm oder Skript).',
    macro_document: 'Office-Dokument mit Makros – Makros können Schadcode enthalten.',
    apk: 'Android-App-Paket (APK). Wird nicht geöffnet.',
    download_execute: 'Befehl lädt etwas aus dem Netz und führt es sofort aus.',
    encoded_command: 'Verschleierter (kodierter) Befehl – wird häufig von Schadsoftware benutzt.',
    destructive_command: 'Befehl, der Daten unwiderruflich löschen kann.',
    reverse_shell: 'Befehl öffnet eine Fernsteuerung („Reverse Shell“) zu einem fremden Rechner.',
    script_content: 'Enthält ausführbaren Skriptcode (z. B. <script>, eval).',
    pdf_script: 'PDF mit eingebettetem Skript oder Startaktion.',
    prompt_injection: 'Enthält Anweisungen, die versuchen, die KI zu manipulieren (Prompt-Injection).',
    html_script: 'Enthält eingebetteten Skriptcode (HTML/JavaScript).'
  };
  var CODE_LEVEL = {
    dangerous_scheme: MAL, eicar: MAL, double_extension: MAL, magic_mismatch: MAL, download_execute: MAL,
    encoded_command: MAL, destructive_command: MAL, reverse_shell: MAL
  };

  function result(items) {
    var level = CLEAN, codes = [];
    for (var i = 0; i < items.length; i++) {
      var c = items[i][0], l = items[i][1];
      if (codes.indexOf(c) < 0) codes.push(c);
      if (l === MAL) level = MAL; else if (l === SUS && level !== MAL) level = SUS;
    }
    return { level: level, findings: codes };
  }

  /* ---------- URLs ---------- */
  var SHORTENERS = ['bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 'rebrand.ly', 'cutt.ly', 'shorturl.at', 'tiny.cc', 'rb.gy'];
  var BRANDS = {
    paypal: ['paypal.com', 'paypal.me', 'paypal.de'],
    google: ['google.com', 'google.de', 'googleapis.com', 'gstatic.com', 'withgoogle.com', 'googleusercontent.com', 'blog.google'],
    apple: ['apple.com', 'icloud.com'],
    microsoft: ['microsoft.com'],
    amazon: ['amazon.com', 'amazon.de', 'amazon.co.uk', 'amazon.fr', 'amazon.it', 'amazon.es', 'amazonaws.com'],
    facebook: ['facebook.com'],
    instagram: ['instagram.com'],
    netflix: ['netflix.com'],
    sparkasse: ['sparkasse.de'],
    volksbank: ['volksbank.de'],
    dhl: ['dhl.de', 'dhl.com'],
    ebay: ['ebay.com', 'ebay.de'],
    steam: ['steampowered.com', 'steamcommunity.com'],
    whatsapp: ['whatsapp.com', 'whatsapp.net'],
    telegram: ['telegram.org'],
    binance: ['binance.com'],
    commerzbank: ['commerzbank.de'],
    postbank: ['postbank.de']
  };
  var SECOND_LEVEL = ['co', 'com', 'org', 'net', 'gov', 'ac'];

  function registrable(host) {
    var l = host.split('.');
    if (l.length >= 3 && l[l.length - 1].length === 2 && SECOND_LEVEL.indexOf(l[l.length - 2]) >= 0) return l.slice(-3).join('.');
    return l.slice(-2).join('.');
  }

  function scanUrl(url) {
    var u = String(url == null ? '' : url).trim();
    var items = [];
    var sm = /^([a-z][a-z0-9+.\-]*):(?!\d)/i.exec(u);
    if (!sm) return result([['invalid', SUS]]);
    var scheme = sm[1].toLowerCase();
    if (scheme !== 'http' && scheme !== 'https') return result([['dangerous_scheme', MAL]]);
    var rest = u.slice(sm[0].length);
    if (rest.slice(0, 2) !== '//') return result([['invalid', SUS]]);
    rest = rest.slice(2);
    var authority = rest.split(/[\/?#]/)[0];
    var at = authority.lastIndexOf('@');
    var userinfo = at >= 0 ? authority.slice(0, at) : null;
    var hostport = at >= 0 ? authority.slice(at + 1) : authority;
    var host, ipv6 = false;
    if (hostport.charAt(0) === '[') {
      var close = hostport.indexOf(']');
      if (close < 0) return result([['invalid', SUS]]);
      host = hostport.slice(1, close); ipv6 = true;
    } else {
      host = hostport.split(':')[0];
    }
    host = host.toLowerCase();
    if (!host) return result([['invalid', SUS]]);
    if (userinfo !== null) items.push(['userinfo', userinfo.indexOf('.') >= 0 ? MAL : SUS]);
    if (ipv6 || /^\d{1,3}(\.\d{1,3}){3}$/.test(host)) items.push(['ip_host', SUS]);
    var labels = host.split('.');
    if (labels.some(function (x) { return x.indexOf('xn--') === 0; })) items.push(['punycode', SUS]);
    if (!ipv6) {
      var reg = registrable(host);
      if (SHORTENERS.indexOf(host) >= 0 || SHORTENERS.indexOf(reg) >= 0) items.push(['shortener', SUS]);
      Object.keys(BRANDS).forEach(function (b) {
        if (host.indexOf(b) >= 0) {
          var ok = BRANDS[b].indexOf(reg) >= 0 || (b === 'google' && /\.google$/.test(host)) || (b === 'apple' && /\.apple$/.test(host));
          if (!ok) items.push(['brand_spoof', SUS]);
        }
      });
      if (labels.length >= 5) items.push(['deep_subdomain', SUS]);
    }
    return result(items);
  }

  /* ---------- Text (Prompt-Injection, HTML) ---------- */
  function fold(s) {
    s = String(s).toLowerCase();
    s = s.replace(/\u00e4/g, 'ae').replace(/\u00f6/g, 'oe').replace(/\u00fc/g, 'ue').replace(/\u00df/g, 'ss');
    return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }
  var INJECTION = [
    /ignore (all |any |the |your )?(previous|prior|above|earlier|preceding) (instructions|rules|prompts?|directions|messages)/,
    /ignoriere (alle |jegliche |die |deine )?(vorherigen |bisherigen |obigen |frueheren |vorigen )?(anweisungen|regeln|instruktionen|vorgaben|befehle)/,
    /vergiss (alle |deine |die )?(vorherigen |bisherigen )?(anweisungen|regeln|instruktionen|vorgaben)/,
    /(reveal|show|print|leak|repeat|output) (me )?(your|the) (system|hidden|initial) (prompt|instructions?|message)/,
    /(gib|zeig|nenn|verrate|wiederhole)\w* (mir )?(deinen|den|dein) (system ?prompt|systemprompt|system anweisungen|geheimen anweisungen)/,
    /(du bist jetzt|you are now|tue so als|pretend (to be|you are)) (dan|jailbroken|unrestricted|ohne regeln|without (any )?(rules|restrictions)|in developer mode|im entwicklermodus)/,
    /disregard (your|all|any) (safety|guidelines|instructions|rules)/
  ];
  var HTML_SCRIPT = /<\s*script\b|javascript:|\bon(error|load|click)\s*=|<\s*iframe\b/i;

  var CMD_PATTERNS = [
    ['download_execute', /(curl|wget)\s+[^|;\n]*\|\s*(sudo\s+)?(sh|bash|zsh|python\d?)\b/],
    ['download_execute', /powershell[^\n]*(downloadstring|invoke-webrequest|\biwr\b)[^\n]*(iex|invoke-expression)/],
    ['download_execute', /certutil[^\n]*-urlcache|bitsadmin[^\n]*\/transfer/],
    ['encoded_command', /powershell(\.exe)?\s[^\n]*-(enc|encodedcommand)\b/],
    ['encoded_command', /frombase64string[^\n]*(iex|invoke-expression)|(iex|invoke-expression)[^\n]*frombase64string/],
    ['destructive_command', /\brm\s+-[a-z]*r[a-z]*f[a-z]*\s+(\/|~|\*|\$home)(\s|$)/],
    ['destructive_command', /\bformat\s+c:/],
    ['destructive_command', /\bdel\s+\/f\s+\/s\s+\/q\s+c:/],
    ['destructive_command', /:\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:/],
    ['reverse_shell', /bash\s+-i\s+>&\s*\/dev\/tcp\//],
    ['reverse_shell', /\/dev\/tcp\/\d+\.\d+\.\d+\.\d+\/\d+/],
    ['reverse_shell', /\bnc\s+(-e|-c)\s/],
    ['reverse_shell', /socat[^\n]*exec/]
  ];
  var SCRIPT_PATTERNS = [/<\s*script\b/, /\beval\s*\(/, /document\.write\s*\(\s*unescape/, /\bunescape\s*\(/];

  function scanCommands(lower, items) {
    CMD_PATTERNS.forEach(function (p) { if (p[1].test(lower)) items.push([p[0], MAL]); });
    if (SCRIPT_PATTERNS.some(function (r) { return r.test(lower); })) items.push(['script_content', SUS]);
  }

  function scanText(text) {
    var raw = String(text == null ? '' : text);
    var items = [];
    var f = fold(raw).replace(/[^a-z0-9]+/g, ' ').trim();
    if (INJECTION.some(function (r) { return r.test(f); })) items.push(['prompt_injection', SUS]);
    if (HTML_SCRIPT.test(raw)) items.push(['html_script', SUS]);
    scanCommands(raw.toLowerCase(), items);
    return result(items);
  }

  /* ---------- Dateien ---------- */
  var EXEC_EXT = ['exe', 'dll', 'bin', 'so', 'dex', 'elf', 'out', 'o', 'ko', 'sys', 'com', 'msi', 'scr'];
  var DANGEROUS_EXT = ['exe', 'scr', 'bat', 'cmd', 'com', 'msi', 'vbs', 'vbe', 'jse', 'wsf', 'ps1', 'lnk', 'dll', 'apk', 'jar', 'sh', 'hta', 'reg', 'pif'];
  var MACRO_EXT = ['docm', 'xlsm', 'pptm', 'dotm', 'xlam'];
  var DOUBLE_RE = /\.(pdf|doc|docx|xls|xlsx|jpg|jpeg|png|gif|txt|mp3|mp4|zip|rar)\.(exe|scr|bat|cmd|com|msi|vbs|js|jar|ps1|lnk|apk|sh|dll)$/;
  var EICAR = 'EICAR-STANDARD-ANTIVIRUS-TEST-FILE!';
  var MAX_SCAN = 4 * 1024 * 1024;

  function latin1(bytes, n) {
    var len = Math.min(bytes.length, n), out = '', CH = 8192;
    for (var i = 0; i < len; i += CH) out += String.fromCharCode.apply(null, Array.prototype.slice.call(bytes, i, Math.min(len, i + CH)));
    return out;
  }
  function magicType(b) {
    function at(i) { return b.length > i ? b[i] : -1; }
    if (at(0) === 0x4d && at(1) === 0x5a) return 'exe';
    if (at(0) === 0x7f && at(1) === 0x45 && at(2) === 0x4c && at(3) === 0x46) return 'elf';
    var w = [at(0), at(1), at(2), at(3)].join(',');
    if (['254,237,250,206', '254,237,250,207', '206,250,237,254', '207,250,237,254', '202,254,186,190'].indexOf(w) >= 0) return 'macho';
    if (at(0) === 0x64 && at(1) === 0x65 && at(2) === 0x78 && at(3) === 0x0a) return 'dex';
    if (at(0) === 0x50 && at(1) === 0x4b && at(2) === 0x03 && at(3) === 0x04) return 'zip';
    if (at(0) === 0x25 && at(1) === 0x50 && at(2) === 0x44 && at(3) === 0x46) return 'pdf';
    return 'other';
  }
  function looksText(b) {
    var n = Math.min(b.length, 4096), printable = 0;
    if (n === 0) return true;
    for (var i = 0; i < n; i++) {
      var c = b[i];
      if (c === 0) return false;
      if (c === 9 || c === 10 || c === 13 || (c >= 32 && c < 127) || c >= 128) printable++;
    }
    return printable / n > 0.85;
  }

  function scanFile(name, bytes) {
    var items = [];
    var nm = String(name == null ? '' : name).toLowerCase().trim();
    var b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    var dot = nm.lastIndexOf('.');
    var ext = dot >= 0 ? nm.slice(dot + 1) : '';
    var scan = b.length > MAX_SCAN ? b.subarray(0, MAX_SCAN) : b;
    var lat = latin1(scan, MAX_SCAN);

    if (lat.indexOf(EICAR) >= 0) items.push(['eicar', MAL]);

    var magic = magicType(scan);
    var execMagic = magic === 'exe' || magic === 'elf' || magic === 'macho' || magic === 'dex';
    if (DOUBLE_RE.test(nm)) items.push(['double_extension', MAL]);
    if (execMagic) {
      if (EXEC_EXT.indexOf(ext) >= 0 || ext === '') items.push(['executable', SUS]);
      else if (DANGEROUS_EXT.indexOf(ext) >= 0) items.push(['executable', SUS]);
      else { items.push(['executable', SUS]); items.push(['magic_mismatch', MAL]); }
    }
    if (DANGEROUS_EXT.indexOf(ext) >= 0) items.push(['dangerous_extension', SUS]);
    if (MACRO_EXT.indexOf(ext) >= 0) items.push(['macro_document', SUS]);
    if (magic === 'zip' && lat.indexOf('AndroidManifest.xml') >= 0) items.push(['apk', SUS]);
    if (magic === 'pdf' && (lat.indexOf('/JavaScript') >= 0 || lat.indexOf('/Launch') >= 0)) items.push(['pdf_script', SUS]);

    if (!execMagic && magic !== 'zip' && looksText(scan)) {
      var text;
      try { text = new TextDecoder('utf-8').decode(scan); } catch (e) { text = lat; }
      var tr = scanText(text.slice(0, 1024 * 1024));
      tr.findings.forEach(function (c) { items.push([c, CODE_LEVEL[c] || SUS]); });
    }
    return result(items);
  }

  function describe(code) { return DESCRIPTIONS[code] || code; }

  return { scanUrl: scanUrl, scanText: scanText, scanFile: scanFile, describe: describe, LEVELS: { CLEAN: CLEAN, SUSPICIOUS: SUS, MALICIOUS: MAL } };
});
