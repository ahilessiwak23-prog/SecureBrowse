/* ContentSafety – Schutz vor Anleitungen zu illegalen Waffen/Sprengstoff und harten Drogen.
 *
 * Ehrlich: Das ist ein lokaler Mustererkenner (Heuristik), kein Allheilmittel. Er fängt die typischen
 * "Wie baue/koche/kaufe ich …"-Anfragen (Deutsch + Englisch) ab, erlaubt aber Aufklärung, Geschichte,
 * Waffenrecht, Hilfe bei Sucht usw. Die KI selbst hat zusätzlich eigene Sicherheitsregeln (Systemprompt).
 * Referenzimplementierung – die Kotlin-Version (security/ContentSafety.kt) ist ein 1:1-Port.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ContentSafety = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MESSAGES = {
    weapons: 'Dabei kann ich dir nicht helfen: Anleitungen zum Bau oder Kauf illegaler Waffen und Sprengstoffe gebe ich nicht. ' +
      'Ich erkläre dir aber gern die Geschichte, das Waffenrecht oder Sicherheitsthemen.',
    drugs: 'Dabei kann ich dir nicht helfen: Herstellung, Kauf oder Handel mit illegalen Drogen unterstütze ich nicht. ' +
      'Wenn du Fragen zu Wirkung, Risiken oder Hilfe bei Sucht hast, helfe ich gern. ' +
      'Hilfe findest du bei einer Suchtberatungsstelle in deiner Nähe oder bei der Telefonseelsorge (0800 111 0 111, kostenlos).'
  };

  /* ---------- Normalisierung ---------- */
  function fold(s) {
    s = String(s).toLowerCase();
    s = s.replace(/[​-‏⁠﻿]/g, '');
    s = s.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
    s = s.normalize('NFD').replace(/[̀-ͯ]/g, '');
    return s;
  }
  function plainForm(s) {
    return fold(s).replace(/[^a-z0-9]+/g, ' ').trim();
  }
  function leetForm(s) {
    var f = fold(s);
    var map = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's' };
    f = f.replace(/[0134557@$]/g, function (c) { return map[c] || c; });
    return f.replace(/[^a-z0-9]+/g, ' ').trim();
  }
  /* "b o m b e" / "B.O.M.B.E" -> "bombe": Folgen aus mindestens 3 einzelnen Zeichen werden zusammengezogen. */
  function joinSingles(s) {
    return s.replace(/(?:^| )((?:[a-z0-9] ){2,}[a-z0-9])(?= |$)/g, function (m, g) {
      return (m.charAt(0) === ' ' ? ' ' : '') + g.replace(/ /g, '');
    });
  }

  /* Token-Indizes aller Treffer eines globalen Regex in einer Zeichenkette aus Tokens (Trenner: ein Leerzeichen). */
  function idxs(str, re) {
    var out = [], m;
    re.lastIndex = 0;
    while ((m = re.exec(str)) !== null) {
      out.push(str.slice(0, m.index).split(' ').length - 1);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
    return out;
  }
  function near(a, b, d) {
    for (var i = 0; i < a.length; i++) for (var j = 0; j < b.length; j++) if (Math.abs(a[i] - b[j]) <= d) return true;
    return false;
  }
  function has(str, re) { re.lastIndex = 0; return re.test(str); }

  /* ---------- Wortlisten (alles klein, ASCII, Umlaute aufgelöst) ---------- */
  var EXPLOSIVE_NOUN = /\b(bombe|bomben|rohrbombe|nagelbombe|autobombe|paketbombe|sprengstoff|sprengstoffe|sprengsatz|sprengkoerper|sprengladung|handgranate|handgranaten|granate|zuender|zuendmechanismus|molotow|molotov|molotowcocktail|molotovcocktail|brandsatz|napalm|thermit|tnt|c4|semtex|pipe bomb|explosive|explosives|explosive device|detonator|grenade|bomb|bombs|dirty bomb|ied)\b/g;
  var GUN_NOUN = /\b(pistole|revolver|gewehr|waffe|waffen|schusswaffe|schusswaffen|maschinenpistole|sturmgewehr|kalaschnikow|schalldaempfer|ghost gun|ghostgun|silencer|suppressor|firearm|firearms|gun|guns|rifle|pistol|weapon|weapons)\b/g;
  var STRONG_BUILD = /\b(bau|baue|bauen|baut|bauanleitung|zusammenbauen|zusammenbau|basteln|bastle|bastelt|herstellen|herstellung|anfertigen|anfertigung|fertigen|produzieren|produziere|produktion|konstruieren|konstruiere|make|making|build|building|create|craft|assemble|manufacture|manufacturing|produce|construct|synthesize|synthesise)\b/g;
  var WEAK_BUILD = /\b(mache|machen|macht|kochen|mischen|zusammenmischen|anleitung|recipe|tutorial|instructions|diy|selber|selbst|zuhause|at home)\b/g;
  var ILLEGAL_CUE = /\b(illegal\w*|darknet|dark web|darkweb|schwarzmarkt|black market|untraceable|unregistered|nicht rueckverfolgbar|unter der hand|schwarz kaufen)\b|\bohne (waffenschein|waffenbesitzkarte|erlaubnis|lizenz|license|licence|background check|registrierung|ausweis|kontrolle|papiere)\b|\bwithout (a )?(license|licence|background check|permit|registration|papers)\b/;
  var ACQUIRE = /\b(kaufen|kaufe|kauf|bestellen|bestelle|besorgen|besorge|beschaffen|organisieren|buy|order|purchase|acquire|get)\b/g;
  var ACQUIRE_PHRASE = /\b(komme ich an|wo gibt es|wo bekomme|wo kriege|an eine waffe kommen)\b/g;
  var GAME_CUE = /\b(minecraft|fortnite|roblox|terraria|gta|lego|call of duty|warzone|battlefield|valorant|counter strike|fallout|skyrim|zelda|bath bomb|bade bombe|photo bomb|foto bombe)\b/;
  var REAL_CUE = /\b(echt|echte|echten|real life|in echt|wirklich|irl|really)\b/;
  var HISTORY_CUE = /\b(geschichte|historisch\w*|history|historical|weltkrieg|wwii|ww2|mittelalter|manhattan|winterkrieg|museum|film|dokumentation|erfunden|erfinder)\b/;
  var INSTRUCTION_CUE = /\b(anleitung|schritt fuer schritt|step by step|tutorial|how to|zuhause|zu hause|at home|selbst|selber|diy|recipe|zutaten|materialien|was brauche ich)\b/;

  var AUTOMATIC = /\b(vollautomat\w*|full auto\w*|dauerfeuer|automatikfeuer)\b/;
  var CONVERT_VERB = /\b(umbau\w*|umruest\w*|modifi\w*|convert\w*|bau\w*|aender\w*|umwandel\w*|freischalten|um)\b/;
  var DECO_WEAPON = /\b(dekowaffe|deko waffe|dekorationswaffe|deko pistole|deko gewehr|deko revolver)\b/;
  var REACTIVATE = /\b(scharf|reaktivier\w*|funktionsfaehig|schussfaehig|wiederherstell\w*|umbau\w*)\b/;
  var THREE_D = /\b(3d|dreid|3 d)\b/g;
  var MODEL_CUE = /\b(modell|miniatur\w*|figur|spielfigur|spielzeug|cosplay|requisite|prop|toy|model|miniature|figurine)\b/;
  var FUNCTIONAL_CUE = /\b(funktionsfaehig|schussfaehig|scharf|functional|working|firing|schiessen|shoot|echt|echte|real)\b/;

  var CHEMBIO_AGENT = /\b(sarin|tabun|vx|senfgas|nervengas|nerve agent|nervenkampfstoff|anthrax|milzbrand|rizin|ricin|biowaffe|bioweapon|chemiewaffe|chemical weapon|kampfstoff|botulinum)\b/g;
  var CHEMBIO_VERB = /\b(herstell\w*|synthetisier\w*|synthesi[sz]e|zuecht\w*|kultivier\w*|produzier\w*|make|synthesis|produce|cultivate|grow|weaponi[sz]e|waffenfaehig|extrahier\w*|isolier\w*|brew|brauen|braue)\b/g;

  var HARD_DRUG = /\b(meth|methamphetamin\w*|crystal|crystal meth|heroin|kokain|cocain\w*|cocaine|koks|crack|mdma|ecstasy|xtc|lsd|fentanyl\w*|amphetamin\w*|ketamin|ghb|dmt|opium|psilocybin\w*|zauberpilz\w*|magic mushroom\w*|pcp|mescalin\w*|meskalin\w*|designerdroge\w*)\b/g;
  var ANY_DRUG = /\b(meth|methamphetamin\w*|crystal|crystal meth|heroin|kokain|cocain\w*|cocaine|koks|crack|mdma|ecstasy|xtc|lsd|fentanyl\w*|amphetamin\w*|ketamin|ghb|dmt|opium|psilocybin\w*|zauberpilz\w*|magic mushroom\w*|pcp|mescalin\w*|meskalin\w*|designerdroge\w*|drogen|droge|drugs|drug|betaeubungsmittel)\b/g;
  var GENERIC_DRUG = /\b(drogen|droge|drugs|drug|betaeubungsmittel)\b/g;
  var DRUG_SYNTH = /\b(koche|kochen|kocht|kochst|cook|brauen|braue|brew|herstell\w*|synthetisier\w*|synthesi[sz]e|synthesis|produzier\w*|produce|make|extrahier\w*|extract|isolier\w*|anbau\w*|anbauen|anpflanzen|grow|cultivate|zuecht\w*|kultivier\w*|manufacture|bau|baue|bauen|baut|zusammenmischen|anleitung|tutorial|instructions|recipe)\b/g;
  var DRUG_ACQUIRE = /\b(kaufen|kaufe|kauf|bestellen|bestelle|besorgen|besorge|beschaffen|buy|order|purchase)\b/g;
  var DRUG_ACQUIRE_PHRASE = /\b(komme ich an|wo gibt es|wo bekomme|wo kriege)\b/g;
  var DRUG_CUE = /\b(darknet|dark web|darkweb|dealer|strasse|schwarzmarkt|anonym|ohne erwischt|untergrund)\b/;
  var DRUG_DEAL = /\b(verkauf\w*|dealen|deale|schmuggel\w*|schmuggle\w*|vertreiben|sell|smuggle\w*|traffick\w*|strecken|strecke|streck\w*)\b/g;
  var LEGAL_CUE = /\b(strafbar|strafe|strafen|strafrecht|rechtslage|rechtlich\w*|gesetz\w*|was passiert|was droht|law|legal status)\b/;

  function buildPositions(str) {
    var p = idxs(str, STRONG_BUILD);
    if (has(str, /\bstell\w*\b/)) p = p.concat(idxs(str, /\bher\b/g));
    return p;
  }

  function evaluate(str) {
    if (!str) return null;
    var gameExempt = has(str, GAME_CUE) && !has(str, REAL_CUE);

    var exp = idxs(str, EXPLOSIVE_NOUN);
    var gun = idxs(str, GUN_NOUN);
    var anyNoun = exp.concat(gun);
    var strong = buildPositions(str);

    // W1: Bau/Herstellung von Waffen/Sprengstoff
    if (!gameExempt) {
      var w1 = near(anyNoun, strong, 8) || near(exp, idxs(str, WEAK_BUILD), 6);
      if (w1 && !(has(str, HISTORY_CUE) && !has(str, INSTRUCTION_CUE))) return { category: 'weapons', rule: 'W1' };
    }
    // W2: illegaler Erwerb
    if (anyNoun.length) {
      var acq = idxs(str, ACQUIRE).concat(idxs(str, ACQUIRE_PHRASE));
      if (acq.length && has(str, ILLEGAL_CUE) && near(anyNoun, acq, 10)) return { category: 'weapons', rule: 'W2' };
    }
    // W3: Umbau auf Vollautomatik / Dekowaffe scharf machen
    if (has(str, AUTOMATIC) && has(str, CONVERT_VERB)) return { category: 'weapons', rule: 'W3' };
    if (has(str, DECO_WEAPON) && has(str, REACTIVATE)) return { category: 'weapons', rule: 'W3' };
    // W4: Chemie-/Biowaffen
    var agents = idxs(str, CHEMBIO_AGENT);
    if (agents.length && near(agents, idxs(str, CHEMBIO_VERB), 8)) return { category: 'weapons', rule: 'W4' };
    // W5: 3D-gedruckte Waffen
    if (!gameExempt && gun.length && near(gun, idxs(str, THREE_D), 6) && !(has(str, MODEL_CUE) && !has(str, FUNCTIONAL_CUE))) {
      return { category: 'weapons', rule: 'W5' };
    }

    // D1: Herstellung harter Drogen
    var hard = idxs(str, HARD_DRUG);
    var anyDrug = idxs(str, ANY_DRUG);
    var synth = idxs(str, DRUG_SYNTH);
    if (has(str, /\bstell\w*\b/)) synth = synth.concat(idxs(str, /\bher\b/g));
    if (near(anyDrug, synth, 8)) {
      // "anleitung/tutorial/instructions/recipe" allein zählen nur bei harten Drogen
      var strongSynth = idxs(str, /\b(koche|kochen|kocht|kochst|cook|brauen|braue|brew|herstell\w*|synthetisier\w*|synthesi[sz]e|synthesis|produzier\w*|produce|make|extrahier\w*|extract|isolier\w*|anbau\w*|anpflanzen|grow|cultivate|zuecht\w*|kultivier\w*|manufacture|bau|baue|bauen|baut|zusammenmischen)\b/g);
      if (has(str, /\bstell\w*\b/)) strongSynth = strongSynth.concat(idxs(str, /\bher\b/g));
      if (near(anyDrug, strongSynth, 8) || near(hard, synth, 8)) return { category: 'drugs', rule: 'D1' };
    }
    // D2: Erwerb
    var dacq = idxs(str, DRUG_ACQUIRE).concat(idxs(str, DRUG_ACQUIRE_PHRASE));
    if (dacq.length) {
      if (near(hard, dacq, 8)) return { category: 'drugs', rule: 'D2' };
      if (near(idxs(str, GENERIC_DRUG), dacq, 8) && has(str, DRUG_CUE)) return { category: 'drugs', rule: 'D2' };
    }
    // D3: Handel/Schmuggel/Strecken
    if (!has(str, LEGAL_CUE) && near(anyDrug, idxs(str, DRUG_DEAL), 8)) return { category: 'drugs', rule: 'D3' };
    return null;
  }

  function check(text) {
    var plain = plainForm(text);
    var leet = leetForm(text);
    var forms = [plain, leet, joinSingles(plain), joinSingles(leet)];
    var hit = null;
    for (var i = 0; i < forms.length && !hit; i++) {
      if (forms.indexOf(forms[i]) === i) hit = evaluate(forms[i]); // gleiche Formen nur einmal prüfen
    }
    if (!hit) return { blocked: false, category: null, message: '', rule: null };
    return { blocked: true, category: hit.category, message: MESSAGES[hit.category], rule: hit.rule };
  }

  return { check: check, MESSAGES: MESSAGES };
});
