/* SkillRouter – lokale Sprach-/Textbefehle für JARVIS (ohne KI-Modell, ohne Netz).
 * route(text, ctx) -> { handled, reply, action }
 *   handled=false  => Anfrage geht an die KI (lokal/Cloud)
 *   action         => null oder { type: 'open_url'|'search'|'set_accent'|'set_theme_mode'|'set_incognito'|
 *                                  'set_voice_gender'|'adjust_rate'|'timer'|'open_settings'|'clear_cache'|'clear_history', … }
 * ctx = { year, month, day, weekday(1=Mo..7=So), hour, minute, userName?, seed? }
 * Referenzimplementierung – die Kotlin-Version (jarvis/SkillRouter.kt) ist ein 1:1-Port.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SkillRouter = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var ACCENT_NAMES = {
    jarvis: 'Jarvis-Blau', cyan: 'Türkis', green: 'Grün', yellow: 'Gelb', orange: 'Orange',
    red: 'Rot', pink: 'Pink', purple: 'Lila', silver: 'Silber'
  };
  var ACCENT_WORDS = {
    jarvis: 'blau|blue|jarvis', cyan: 'tuerkis|tuerkise|cyan|aqua', green: 'gruen|green', yellow: 'gelb|gold|golden|yellow',
    orange: 'orange', red: 'rot|red', pink: 'pink|rosa|magenta', purple: 'lila|violett|purple|lilac', silver: 'silber|grau|silver'
  };
  var SITES = {
    wikipedia: 'https://de.wikipedia.org', youtube: 'https://www.youtube.com', google: 'https://www.google.com',
    tagesschau: 'https://www.tagesschau.de', github: 'https://github.com', duckduckgo: 'https://duckduckgo.com',
    amazon: 'https://www.amazon.de', ebay: 'https://www.ebay.de', reddit: 'https://www.reddit.com',
    spiegel: 'https://www.spiegel.de', twitch: 'https://www.twitch.tv', netflix: 'https://www.netflix.com',
    openstreetmap: 'https://www.openstreetmap.org', gmx: 'https://www.gmx.net'
  };
  var WEEKDAYS = ['', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'];
  var MONTHS = ['', 'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  var JOKES = [
    'Warum können Geister so schlecht lügen? Weil man sie durchschaut.',
    'Was sagt ein Null zu einer Acht? Schicker Gürtel!',
    'Warum nehmen Programmierer ihre Brille ab, wenn sie Fehler suchen? Damit sie besser C-Sharp sehen können.',
    'Was ist grün und klopft an die Tür? Ein Klopfsalat.',
    'Wieso ging der Computer zum Arzt? Er hatte einen Virus – und keinen Schutz.',
    'Was macht ein Pirat am Computer? Er drückt die Enter-Taste.'
  ];
  var NOT = { handled: false, reply: '', action: null };

  function fold(s) {
    s = String(s).toLowerCase();
    s = s.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
    return s.normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  function say(reply, action) { return { handled: true, reply: reply, action: action || null }; }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function fmtDur(sec) {
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60, p = [];
    if (h) p.push(h + (h === 1 ? ' Stunde' : ' Stunden'));
    if (m) p.push(m + (m === 1 ? ' Minute' : ' Minuten'));
    if (s) p.push(s + (s === 1 ? ' Sekunde' : ' Sekunden'));
    return p.join(' ') || '0 Sekunden';
  }

  /* ---------- Rechnen (kein eval!) ---------- */
  function parseExpr(s) {
    var pos = 0;
    function peek() { return s.charAt(pos); }
    function skip() { while (peek() === ' ') pos++; }
    function number() {
      skip();
      var m = /^\d+(\.\d+)?|^\.\d+/.exec(s.slice(pos));
      if (!m) throw new Error('num');
      pos += m[0].length; return parseFloat(m[0]);
    }
    function primary() {
      skip();
      if (peek() === '(') { pos++; var v = expr(); skip(); if (peek() !== ')') throw new Error('paren'); pos++; return v; }
      return number();
    }
    function unary() {
      skip();
      if (peek() === '-') { pos++; return -unary(); }
      if (peek() === '+') { pos++; return unary(); }
      return power();
    }
    function power() {
      var b = primary(); skip();
      if (peek() === '^') { pos++; return Math.pow(b, unary()); }
      return b;
    }
    function term() {
      var v = unary();
      for (;;) {
        skip();
        var c = peek();
        if (c === '*') { pos++; v = v * unary(); }
        else if (c === '/') { pos++; var d = unary(); if (d === 0) throw new Error('div0'); v = v / d; }
        else return v;
      }
    }
    function expr() {
      var v = term();
      for (;;) {
        skip();
        var c = peek();
        if (c === '+') { pos++; v = v + term(); }
        else if (c === '-') { pos++; v = v - term(); }
        else return v;
      }
    }
    var r = expr(); skip();
    if (pos !== s.length) throw new Error('trailing');
    return r;
  }
  function fmtNum(r) {
    if (!isFinite(r)) throw new Error('inf');
    if (Math.abs(r) < 1e15 && r === Math.floor(r)) return String(r);
    return String(parseFloat(r.toFixed(6))).replace('.', ',');
  }
  var CALC_TRIGGER = /^(?:was ist|was ergibt|was macht|was sind|wie viel ist|wieviel ist|wie viel ergibt|wieviel ergibt|wie viel sind|wieviel sind|berechne|rechne aus|rechne|ergebnis von|calculate|compute)\s*/;
  function tryCalc(core) {
    var s = core.replace(/[?!=]+\s*$/, '').trim();
    var trig = CALC_TRIGGER.exec(s);
    if (trig) s = s.slice(trig[0].length);
    s = s.replace(/\bmultipliziert mit\b/g, '*').replace(/\bgeteilt durch\b/g, '/').replace(/\bplus\b/g, '+')
      .replace(/\bminus\b/g, '-').replace(/\bmal\b/g, '*').replace(/\bdurch\b/g, '/').replace(/\bhoch\b/g, '^')
      .replace(/(\d),(\d)/g, '$1.$2').trim();
    if (!/^[0-9+\-*\/^().\s]+$/.test(s) || !/\d/.test(s)) return null;
    if (!trig) {
      if (!/[+\-*\/^]/.test(s)) return null;
      if (/^\d{1,4}[-.\/]\d{1,2}[-.\/]\d{1,4}$/.test(s)) return null;
    }
    try { return say('Das ergibt ' + fmtNum(parseExpr(s)) + '.'); }
    catch (e) {
      if (e.message === 'div0') return say('Durch null kann ich nicht teilen.');
      return trig ? say('Das konnte ich nicht ausrechnen.') : null;
    }
  }

  /* ---------- Timer ---------- */
  var WORDNUM = { ein: 1, eine: 1, einen: 1, zwei: 2, drei: 3, vier: 4, fuenf: 5, sechs: 6, sieben: 7, acht: 8, neun: 9, zehn: 10, fuenfzehn: 15, zwanzig: 20, dreissig: 30 };
  function unitSeconds(u) {
    if (/^sek/.test(u)) return 1;
    if (/^min/.test(u)) return 60;
    return 3600;
  }
  function parseTimerSeconds(core) {
    if (/\bhalbe\s+stunde\b/.test(core)) return 1800;
    if (/\bviertelstunde\b/.test(core)) return 900;
    var m = /(\d+(?:[.,]\d+)?)\s*(sekunden?|sek|minuten?|min|stunden?|std|h)\b/.exec(core);
    if (m) return Math.round(parseFloat(m[1].replace(',', '.')) * unitSeconds(m[2]));
    m = /\b(ein|eine|einen|zwei|drei|vier|fuenf|sechs|sieben|acht|neun|zehn|fuenfzehn|zwanzig|dreissig)\s+(sekunden?|minuten?|stunden?)\b/.exec(core);
    if (m) return WORDNUM[m[1]] * unitSeconds(m[2]);
    return 0;
  }

  /* ---------- Hauptfunktion ---------- */
  function route(text, ctx) {
    ctx = ctx || {};
    var raw = String(text == null ? '' : text).trim();
    if (!raw) return NOT;
    var f = fold(raw);
    var plain = f.replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();

    var name = ctx.userName ? ' ' + ctx.userName : '';
    if (/^(?:(?:hey|hi|hallo|hello|servus|moin|guten morgen|guten tag|guten abend|gute nacht)\s*)+(?:jarvis)?$/.test(plain) || plain === 'jarvis') {
      return say('Hallo' + name + '! Ich bin JARVIS. Was kann ich für dich tun?');
    }

    var wake = /^(?:(?:hey|hi|hallo|hello|ok|okay)\s+)?jarvis\b[\s,.:!]*/;
    var core = f.replace(wake, '').replace(/\bbitte\b/g, ' ').replace(/\s+/g, ' ').trim();
    var rawCore = raw.replace(/^(?:(?:hey|hi|hallo|hello|ok|okay)\s+)?jarvis\b[\s,.:!]*/i, '').replace(/\bbitte\b/gi, ' ').replace(/\s+/g, ' ').trim();
    if (!core) return NOT;
    var coreTok = core.split(' '), rawTok = rawCore.split(' ');
    function rawTail(n) { return rawTok.length === coreTok.length ? rawTok.slice(rawTok.length - n).join(' ') : coreTok.slice(coreTok.length - n).join(' '); }
    var m;

    // Einstellungen öffnen
    if (/^(?:oeffne|oeffnen|zeig|zeige|gehe?\s+(?:zu|in|auf)|starte)\s+(?:die\s+|den\s+|meine\s+|mir\s+die\s+)?(?:einstellungen|settings)$/.test(core)) {
      return say('Ich öffne die Einstellungen.', { type: 'open_settings' });
    }
    // Aufräumen
    if (/\b(?:cache|zwischenspeicher)\s+(?:loeschen|leeren|bereinigen)\b|\b(?:loesche|leere|bereinige)\s+(?:den\s+)?(?:cache|zwischenspeicher)\b/.test(core)) {
      return say('Ich leere den Cache.', { type: 'clear_cache' });
    }
    if (/\b(?:verlauf|chronik|history)\s+(?:loeschen|leeren)\b|\b(?:loesche|leere)\s+(?:den\s+)?(?:verlauf|chronik)\b/.test(core)) {
      return say('Ich lösche den Verlauf.', { type: 'clear_history' });
    }
    // Inkognito
    if (/\b(?:inkognito|incognito|privater modus)\b|\bprivat surfen\b/.test(core)) {
      var off = /\b(?:aus|ausschalten|ausmachen|beenden|deaktivieren|verlassen|off)\b/.test(core);
      return say(off ? 'Inkognito-Modus ist aus.' : 'Inkognito-Modus ist an. Neue Tabs speichern nichts.', { type: 'set_incognito', on: !off });
    }
    // Stimme
    if (/\b(?:stimme|voice|sprecher\w*)\b/.test(core) && (m = /\b(maennlich\w*|weiblich\w*|neutral\w*)\b/.exec(core))) {
      var g = m[1].indexOf('weiblich') === 0 ? 'female' : m[1].indexOf('maennlich') === 0 ? 'male' : 'neutral';
      var gl = g === 'female' ? 'weiblich' : g === 'male' ? 'männlich' : 'neutral';
      return say('Stimme: ' + gl + '.', { type: 'set_voice_gender', gender: g });
    }
    if (/\b(?:sprich|sprech\w*|rede|redest)\b/.test(core) && (m = /\b(schneller|langsamer)\b/.exec(core))) {
      var up = m[1] === 'schneller';
      return say(up ? 'Okay, ich spreche schneller.' : 'Okay, ich spreche langsamer.', { type: 'adjust_rate', delta: up ? 0.15 : -0.15 });
    }
    // Timer
    if (/\b(?:timer|wecker|stoppuhr|erinnere mich)\b/.test(core)) {
      var secs = Math.min(parseTimerSeconds(core), 86400);
      if (secs > 0) return say('Timer für ' + fmtDur(secs) + ' gestellt.', { type: 'timer', seconds: secs });
      return say('Wie lange soll der Timer laufen? Sag zum Beispiel: „Timer 5 Minuten“.');
    }
    // Hell/Dunkel
    if (/\b(?:dunkelmodus|dark ?mode|nachtmodus|dunkler modus|dunkles (?:design|theme)|mach (?:es|alles) dunkel)\b/.test(core)) {
      return say('Dunkles Design ist an.', { type: 'set_theme_mode', mode: 'dark' });
    }
    if (/\b(?:hellmodus|light ?mode|heller modus|helles (?:design|theme)|tagmodus|mach (?:es|alles) hell)\b/.test(core)) {
      return say('Helles Design ist an.', { type: 'set_theme_mode', mode: 'light' });
    }
    if (/\b(?:automatischer modus|systemmodus)\b/.test(core)) {
      return say('Das Design folgt jetzt dem System.', { type: 'set_theme_mode', mode: 'auto' });
    }
    // Webseite öffnen
    if ((m = /^(?:oeffne|oeffnen|starte|gehe?\s+(?:zu|auf|nach)|geh\s+(?:zu|auf)|open|launch|besuche|navigiere\s+zu|zeig(?:e)?\s+mir)\s+(?:die\s+|den\s+|das\s+|seite\s+|website\s+|webseite\s+)?(\S+)$/.exec(core))) {
      var target = m[1].replace(/[?!,;]+$/, '');
      if (SITES[target]) return say('Ich öffne ' + target + '.', { type: 'open_url', url: SITES[target] });
      if (/^[a-z0-9][a-z0-9-]*(\.[a-z0-9-]+)+(\/\S*)?$/.test(target)) {
        var rt = rawTail(1).replace(/[?!,;]+$/, '');
        var slash = rt.indexOf('/');
        var hostPart = (slash >= 0 ? rt.slice(0, slash) : rt).toLowerCase();
        var url = 'https://' + hostPart + (slash >= 0 ? rt.slice(slash) : '');
        return say('Ich öffne ' + hostPart + '.', { type: 'open_url', url: url });
      }
      return NOT;
    }
    // Suchen
    if ((m = /^(?:suche?|such|google|bing|recherchiere|search)\s+(?:mal\s+)?(?:nach\s+|for\s+)?(.+)$/.exec(core))) {
      var q = rawTail(m[1].split(' ').length).replace(/[?!.]+$/, '').trim();
      if (q) return say('Ich suche nach „' + q + '“.', { type: 'search', query: q });
      return say('Wonach soll ich suchen?');
    }
    // Farbe
    if (/\b(?:farbe|farben|theme|design|akzent|wechsl\w*|wechsel\w*|schalte?\s+auf|mach\s+(?:es|alles|die\s+app)|zurueck\s+(?:zu|auf)|stell\w*\s+auf|nimm)\b/.test(core)) {
      var ids = Object.keys(ACCENT_WORDS);
      for (var i = 0; i < ids.length; i++) {
        if (new RegExp('\\b(?:' + ACCENT_WORDS[ids[i]] + ')\\b').test(core)) {
          return say('Farbe: ' + ACCENT_NAMES[ids[i]] + '.', { type: 'set_accent', id: ids[i] });
        }
      }
    }
    // Rechnen
    var calc = tryCalc(core);
    if (calc) return calc;
    // Uhrzeit
    if ((m = /\b(?:wie\s+spaet|wie\s+viel\s+uhr|wieviel\s+uhr|uhrzeit|welche\s+uhrzeit)\b/.exec(core))) {
      if (/\bin\s+\w+/.test(core.slice(m.index + m[0].length))) return NOT;
      return say('Es ist ' + pad2(ctx.hour || 0) + ':' + pad2(ctx.minute || 0) + ' Uhr.');
    }
    // Datum
    if (/\b(?:welcher\s+tag|welches\s+datum|datum|welchen\s+tag|welcher\s+wochentag|den\s+wievielten)\b/.test(core)) {
      return say('Heute ist ' + WEEKDAYS[ctx.weekday || 1] + ', der ' + ctx.day + '. ' + MONTHS[ctx.month || 1] + ' ' + ctx.year + '.');
    }
    var words = core.split(' ').length;
    if (/\b(?:wer\s+bist\s+du|wie\s+heisst\s+du|stell\s+dich\s+vor)\b/.test(core)) {
      return say('Ich bin JARVIS, dein Assistent in SecureBrowse. Ich öffne Webseiten, suche, rechne, stelle Timer und passe die App für dich an – und mit einem KI-Modell beantworte ich auch Fragen.');
    }
    if (words <= 6 && /\b(?:was\s+kannst\s+du|hilfe|help|befehle|funktionen)\b/.test(core)) {
      return say('Das kann ich lokal: Uhrzeit und Datum, rechnen, Webseiten öffnen („öffne Wikipedia“), suchen („suche nach …“), Timer stellen („Timer 5 Minuten“), Farben und Modus wechseln („Farbe Pink“, „Dunkelmodus“), Inkognito an/aus, die Stimme ändern, Cache und Verlauf löschen und die Einstellungen öffnen. Alles andere beantworte ich mit einem KI-Modell, sobald eines eingerichtet ist.');
    }
    if (words <= 5 && /\b(?:danke|dankeschoen|vielen dank|thx|thanks|thank you)\b/.test(core)) {
      return say('Gern geschehen!');
    }
    if (/\b(?:witz|joke)\b/.test(core)) {
      var seed = typeof ctx.seed === 'number' ? ctx.seed : (ctx.minute || 0);
      return say(JOKES[Math.abs(seed) % JOKES.length]);
    }
    return NOT;
  }

  return { route: route, ACCENT_NAMES: ACCENT_NAMES, SITES: SITES };
});
