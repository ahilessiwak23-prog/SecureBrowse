# SecureBrowse – lokale Nacharbeit (21.11.2026)

## Änderungen
- Gradle Wrapper SHA-256 für Gradle 9.6.0 in `gradle/wrapper/gradle-wrapper.properties` gesetzt.
- Die beiden Shell-Skripte unter `tools/` ausführbar gemacht (`chmod +x`).

## Nachweisbare lokale Prüfungen
- `bash -n tools/bootstrap-gradle-wrapper.sh tools/add-llama-cpp.sh`: erfolgreich.
- `g++ -std=c++17 -Wall -Wextra -Iapp/src/main/cpp app/src/main/cpp/tests/utf8_stream_test.cpp -o /tmp/securebrowse_utf8`: erfolgreich.
- `/tmp/securebrowse_utf8`: `OK: all utf8_stream tests passed`.

## Nicht möglich in dieser Umgebung
- Wrapper-Generierung: `curl: (6) Could not resolve host: services.gradle.org`.
- llama.cpp-Download: GitHub DNS nicht auflösbar.
- Android Gradle-Build, Dependency-Guard, native Integration, APK/Alignment, Release/R8 und Gerätetest: nicht ausgeführt (Gradle/SDK/NDK/ADB nicht verfügbar).


## Zusätzliche, vom Nutzer übermittelte Prüfausgaben
- Port-Prüfungen meldeten `MemoryAssistant-Port`, `LinkSafety-Port`, `SpeechText-Port` und `ALLE PORT-TESTS OK`.
- Der zuvor gemeldete JS-Port-Assertion-Fehler für Backslash/Userinfo wurde in einer späteren Ausgabe als korrigiert/OK ausgewiesen.
- Weitere übermittelte Ausgaben zeigen Hinweise zu Anrede, Datenbank-Dispatcher, Manifest-Queries (TTS/Spracherkennung), Redirect-Schutz und Dialog-Lokalisierung.
- Diese Ausgaben wurden nicht selbst erneut ausgeführt; Details und Grenzen in `PRUEFBERICHT_ZUSATZ.md`.
