plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

// Native llama.cpp is only built if the sources are present (tools/add-llama-cpp.sh).
// Without them the app still builds; JARVIS then reports that the native runtime is missing.
val llamaPresent = file("src/main/cpp/llama.cpp/CMakeLists.txt").exists()
// OpenVPN-Engine nur, wenn third_party/ics-openvpn vorhanden ist (siehe settings.gradle.kts).
val openVpnPresent = rootProject.findProject(":openvpn") != null
val nativeEnabled = llamaPresent && providers.gradleProperty("securebrowse.disableNative").orNull != "true"

android {
    namespace = "de.deinname.securebrowse"
    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "de.deinname.securebrowse" // placeholder, change before publishing
        minSdk = 26
        targetSdk = 36 // PRUEFEN: raise once API 37 is the official stable target
        versionCode = 1
        versionName = "0.1.0"

        if (nativeEnabled) {
            externalNativeBuild {
                cmake {
                    // Only the JARVIS library is restricted to arm64 (other ABIs of WireGuard stay).
                    abiFilters += "arm64-v8a"
                    arguments += listOf(
                        "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON",
                        // Galaxy A53 class CPUs: armv8.2-a + dot product. NOT armv8.7a (would crash with SIGILL).
                        "-DGGML_CPU_ARM_ARCH=armv8.2-a+dotprod",
                        "-DCMAKE_C_FLAGS=-march=armv8.2-a+dotprod",
                        "-DCMAKE_CXX_FLAGS=-march=armv8.2-a+dotprod"
                    )
                }
            }
        }
    }

    if (nativeEnabled) {
        externalNativeBuild {
            cmake {
                path = file("src/main/cpp/CMakeLists.txt")
                version = "3.22.1"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures { compose = true }

    if (openVpnPresent) {
        // PRUEFEN: srcDir-Syntax mit AGP 9 / eingebautem Kotlin
        sourceSets.getByName("main").java.srcDir("src/openvpn/java")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.runtime)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.icons.extended)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    // Official WireGuard Android tunnel backend (userspace; no root required).
    implementation("com.wireguard.android:tunnel:1.0.20260102")
    if (openVpnPresent) implementation(project(":openvpn")) // GPLv2, PRUEFEN: Flavor/Dimension-Auswahl
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")

    testImplementation(libs.junit)
}

// ---------------------------------------------------------------------------
// Dependency guard: fails the build if a forbidden group appears in the graph.
// Run: ./gradlew :app:verifyNoForbiddenDependencies
// ---------------------------------------------------------------------------
val forbiddenGroupPrefixes = listOf(
    "com.google.android.gms",
    "com.google.firebase",
    "com.google.android.datatransport",
    "com.google.android.play",
    "com.android.billingclient",
    "io.sentry",
    "com.crashlytics",
    "com.google.android.ads",
    "com.google.mlkit"
)

tasks.register("verifyNoForbiddenDependencies") {
    group = "verification"
    description = "Fails if any forbidden (Google Play Services, Firebase, tracking, ...) module is resolved."
    notCompatibleWithConfigurationCache("Inspects the resolved dependency graph at execution time.")
    doLast {
        val violations = sortedSetOf<String>()
        listOf("debugRuntimeClasspath", "releaseRuntimeClasspath").forEach { name ->
            configurations.getByName(name).incoming.resolutionResult.allComponents.forEach { component ->
                val id = component.id
                if (id is org.gradle.api.artifacts.component.ModuleComponentIdentifier &&
                    forbiddenGroupPrefixes.any { id.group == it || id.group.startsWith("$it.") }
                ) {
                    violations += "$name -> ${id.group}:${id.module}:${id.version}"
                }
            }
        }
        if (violations.isNotEmpty()) {
            throw GradleException("Forbidden dependencies found:\n" + violations.joinToString("\n"))
        }
        println("OK: no forbidden dependency groups in debug/release runtime classpath.")
    }
}
