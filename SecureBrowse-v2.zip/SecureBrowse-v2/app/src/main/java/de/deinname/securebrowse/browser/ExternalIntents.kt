package de.deinname.securebrowse.browser

import android.content.Intent
import android.net.Uri

/** Builds a sanitized intent for external schemes. Returns null if the URL must not be opened. */
object ExternalIntents {

    fun build(url: String): Intent? {
        val scheme = url.substringBefore(':', "").lowercase()
        return when (scheme) {
            "mailto", "tel", "sms" ->
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
            "intent" -> runCatching { Intent.parseUri(url, Intent.URI_INTENT_SCHEME) }
                .getOrNull()
                ?.let(::sanitize)
            else -> null
        }
    }

    private fun sanitize(intent: Intent): Intent? {
        val dataScheme = intent.data?.scheme?.lowercase()
        if (dataScheme == "file" || dataScheme == "content") return null
        intent.component = null          // never target a specific (possibly non-exported) component
        intent.selector = null           // blocks the classic selector-based intent redirection
        intent.flags = 0                 // drop URI grant and other flags supplied by the page
        intent.addCategory(Intent.CATEGORY_BROWSABLE)
        return intent
    }
}
