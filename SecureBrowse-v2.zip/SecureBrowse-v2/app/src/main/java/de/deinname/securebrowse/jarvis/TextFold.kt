package de.deinname.securebrowse.jarvis

import java.text.Normalizer
import java.util.Locale

/** Reines Kotlin (keine Android-Typen). Gleiche Normalisierung wie `fold()` in der JS-Referenz. */
internal object TextFold {
    private val COMBINING_MARKS = Regex("[\\u0300-\\u036f]")

    /** Kleinbuchstaben, ä/ö/ü/ß aufgelöst (ae/oe/ue/ss), übrige Akzente entfernt. */
    fun fold(input: String): String {
        var s = input.lowercase(Locale.ROOT)
        s = s.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
        return COMBINING_MARKS.replace(s, "")
    }
}
