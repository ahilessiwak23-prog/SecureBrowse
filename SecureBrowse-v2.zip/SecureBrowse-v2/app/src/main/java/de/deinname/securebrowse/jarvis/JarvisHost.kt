package de.deinname.securebrowse.jarvis

/**
 * Brücke zwischen JARVIS und dem Rest der App. JARVIS (Teil B) ruft diese Funktionen auf,
 * wenn ein lokaler Befehl eine Aktion auslöst („öffne Wikipedia“, „Farbe Pink“, „Inkognito an“ …).
 * Implementiert wird sie von der App-Navigation (Teil A, `AppJarvisHost`).
 *
 * Diese Datei ist der gemeinsame Vertrag – Signaturen nicht ändern, ohne SPEC.md anzupassen.
 */
interface JarvisHost {
    /** Im aktuellen Tab öffnen und zum Browser zurückkehren. Die Adresse wird vorher vom Link-Scan geprüft. */
    fun openUrl(url: String)

    /** Mit der Suchmaschine des Nutzers suchen. */
    fun search(query: String)

    /** Akzentfarbe setzen: jarvis | cyan | green | yellow | orange | red | pink | purple | silver. */
    fun setAccent(id: String)

    /** "auto" | "light" | "dark". */
    fun setThemeMode(mode: String)

    fun setIncognito(on: Boolean)

    fun openSettings()

    fun clearCache()

    fun clearHistory()

    /** Anzeigename des angemeldeten Kontos oder null. */
    fun userName(): String?
}
