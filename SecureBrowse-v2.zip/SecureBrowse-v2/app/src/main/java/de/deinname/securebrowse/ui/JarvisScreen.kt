package de.deinname.securebrowse.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import de.deinname.securebrowse.jarvis.JarvisController
import de.deinname.securebrowse.jarvis.JarvisEngineState
import de.deinname.securebrowse.jarvis.JarvisEvent
import de.deinname.securebrowse.jarvis.JarvisMessage
import de.deinname.securebrowse.jarvis.JarvisModelManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(
    controller: JarvisController,
    modelManager: JarvisModelManager,
    onBack: () -> Unit
) {
    val engine = controller.engine
    val engineState by engine.state.collectAsStateWithLifecycle()
    var enabled by remember { mutableStateOf(controller.isEnabled()) }
    var model by remember { mutableStateOf(modelManager.installedModel()) }
    var profile by remember { mutableStateOf(modelManager.deviceProfile()) }
    var status by remember { mutableStateOf("Noch kein lokales Modell installiert.") }
    var busy by remember { mutableStateOf(false) }
    var copiedBytes by remember { mutableStateOf(0L) }
    var input by remember { mutableStateOf("") }
    var generating by remember { mutableStateOf(false) }
    var streamJob by remember { mutableStateOf<Job?>(null) }
    val messages: SnapshotStateList<JarvisMessage> = remember { mutableStateListOf() }
    val scope = rememberCoroutineScope()

    // Leaving the screen stops a running answer (the model itself stays loaded until unloaded or memory is needed).
    DisposableEffect(Unit) { onDispose { engine.cancel() } }

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                copiedBytes = 0L
                status = "GGUF-Datei wird geprüft und importiert …"
                try {
                    engine.unload() // never replace a file that is still mapped into the running model
                    model = modelManager.importGguf(uri) { copied -> scope.launch { copiedBytes = copied } }
                    status = "Modelldatei importiert. Zum Antworten das Modell laden."
                } catch (error: Exception) {
                    status = error.message ?: "Modellimport fehlgeschlagen."
                } finally {
                    busy = false
                }
            }
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || generating || engineState !is JarvisEngineState.Ready) return
        val history = messages.toList() + JarvisMessage("user", text)
        messages += JarvisMessage("user", text)
        messages += JarvisMessage("assistant", "")
        val index = messages.lastIndex
        input = ""
        streamJob = scope.launch {
            generating = true
            val answer = StringBuilder()
            try {
                engine.stream(history).collect { event ->
                    when (event) {
                        is JarvisEvent.Token -> {
                            answer.append(event.text)
                            messages[index] = messages[index].copy(content = answer.toString())
                        }
                        is JarvisEvent.Done -> status = event.reason.label
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = e.message ?: "Antwort fehlgeschlagen."
            } finally {
                generating = false
                profile = modelManager.deviceProfile()
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("JARVIS") },
            navigationIcon = { TextButton(onClick = onBack) { Text("Zurück") } }
        )
    }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                    Text("JARVIS", style = MaterialTheme.typography.headlineMedium)
                    Text(if (enabled) "Modul eingeschaltet" else "Modul ausgeschaltet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("JARVIS aktivieren")
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = enabled, onCheckedChange = { enabled = it; controller.setEnabled(it) })
                    }
                }
            }

            Text("Lokales KI-Modell", style = MaterialTheme.typography.titleLarge)
            ListItem(
                leadingContent = { Icon(Icons.Filled.Memory, null) },
                headlineContent = { Text(model?.fileName ?: "Kein Modell installiert") },
                supportingContent = {
                    Text(model?.let {
                        "GGUF v${it.formatVersion} · ${formatBytes(it.sizeBytes)} · ${it.tensorCount} Tensoren"
                    } ?: "Wähle eine GGUF-Datei aus deinem Gerätespeicher.")
                }
            )
            if (busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text("Kopiert: ${formatBytes(copiedBytes)}", style = MaterialTheme.typography.bodySmall)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { modelPicker.launch(arrayOf("*/*")) }, enabled = !busy && !generating, modifier = Modifier.weight(1f)) {
                    Text(if (model == null) "Modell auswählen" else "Modell wechseln")
                }
                if (model != null) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            engine.unload()
                            modelManager.removeModel()
                            model = null
                            messages.clear()
                            status = "Lokales Modell entfernt."
                        }
                    }, enabled = !busy && !generating) { Text("Entfernen") }
                }
            }

            if (model != null) {
                when (val state = engineState) {
                    is JarvisEngineState.Ready -> {
                        Text(
                            "Geladen · Kontext ${state.contextSize} Tokens · ${state.threads} Threads",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(onClick = { scope.launch { engine.unload(); profile = modelManager.deviceProfile() } }, enabled = !generating) {
                            Text("Modell entladen (RAM freigeben)")
                        }
                    }
                    JarvisEngineState.Loading -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text("Modell wird geladen …")
                    }
                    else -> {
                        if (state is JarvisEngineState.Failed) {
                            Text(state.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = {
                            scope.launch {
                                profile = modelManager.deviceProfile()
                                try { engine.load() } catch (_: Exception) { /* shown via engineState */ }
                                profile = modelManager.deviceProfile()
                            }
                        }, enabled = !busy) { Text("Modell laden") }
                    }
                }
            }

            if (enabled && engineState is JarvisEngineState.Ready) {
                HorizontalDivider()
                Text("Chat", style = MaterialTheme.typography.titleMedium)
                messages.forEach { message ->
                    val mine = message.role == "user"
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            message.content.ifEmpty { "…" },
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Nachricht an JARVIS") },
                    enabled = !generating,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { send() }, enabled = !generating && input.isNotBlank(), modifier = Modifier.weight(1f)) {
                        Text("Senden")
                    }
                    if (generating) {
                        OutlinedButton(onClick = { engine.cancel() }) { Text("Stopp") }
                    }
                }
                if (generating) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            } else if (enabled && model != null) {
                Text("Lade das Modell, um mit JARVIS zu chatten.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Text("Geräteprüfung", style = MaterialTheme.typography.titleMedium)
            Text("Erkannter Gesamtspeicher: ${formatBytes(profile.totalRamBytes)}")
            Text("Aktuell verfügbar: ${formatBytes(profile.availableRamBytes)}")
            Text("Android-App-Speicherklasse: ${profile.appMemoryClassMb} MB")
            Text("Freier Gerätespeicher: ${formatBytes(profile.freeStorageBytes)}")
            Text("Vorsichtige Empfehlung: ${profile.recommendedModelClass}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (model != null && profile.warnsAboutSize(model!!.sizeBytes)) {
                Text(
                    "Achtung: Diese Modelldatei ist im Verhältnis zum erkannten Arbeitsspeicher groß. Beim Laden wird der Speicher geprüft; zu große Modelle werden abgelehnt.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            HorizontalDivider()
            Text(status, color = if (status.contains("fehlgeschlagen") || status.contains("Ungültig") || status.contains("Abgebrochen")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                if (engine.isNativeAvailable)
                    "Die Antworten werden lokal auf dem Gerät mit llama.cpp erzeugt. Nichts wird an einen Server gesendet."
                else
                    "In diesem Build fehlt die native llama.cpp-Bibliothek (nur arm64-Geräte, llama.cpp muss eingebunden sein, siehe JARVIS_PHASE3.md). Modelle können importiert, aber nicht ausgeführt werden.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    do { value /= 1024.0; unit++ } while (value >= 1024.0 && unit < units.lastIndex)
    return String.format(Locale.GERMANY, "%.1f %s", value, units[unit])
}
