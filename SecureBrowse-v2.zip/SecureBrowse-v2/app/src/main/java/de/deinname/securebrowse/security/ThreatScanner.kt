package de.deinname.securebrowse.security

import java.text.Normalizer

enum class ThreatLevel { CLEAN, SUSPICIOUS, MALICIOUS }

/** [findings] sind stabile Codes (siehe [ThreatScanner.describe]). */
data class ScanResult(val level: ThreatLevel, val findings: List<String>)

/**
 * ThreatScanner – "Virenschutz" für die KI-Eingaben: Links, Texte, Dateien.
 *
 * Ehrlich: Das ist KEIN Ersatz für ein echtes Antivirenprogramm. Er erkennt typische Warnzeichen
 * (Testsignatur EICAR, ausführbare Dateien, getarnte Dateiendungen, Download-&-Ausführen-Muster,
 * Skripte, Phishing-Link-Tricks, Prompt-Injection). Er liest Dateien nur als Bytes und führt nie etwas aus.
 *
 * 1:1-Port von web/src/js/11-threat.js (Muster mechanisch übernommen). Reines Kotlin (keine android.*-Imports).
 */
object ThreatScanner {
    private val MAL = ThreatLevel.MALICIOUS
    private val SUS = ThreatLevel.SUSPICIOUS

    private val DESCRIPTIONS: Map<String, String> = mapOf(
        "dangerous_scheme" to "Dieser Link-Typ kann Code ausführen oder lokale Dateien lesen und wird blockiert.",
        "userinfo" to "Die Adresse enthält „Name@“ vor dem Servernamen – ein typischer Trick, um eine falsche Seite echt aussehen zu lassen.",
        "ip_host" to "Die Adresse nutzt eine reine IP-Adresse statt eines Namens.",
        "punycode" to "Der Servername enthält Sonderzeichen-Kodierung (xn--), die oft für täuschend ähnliche Adressen benutzt wird.",
        "brand_spoof" to "Der Servername enthält einen bekannten Markennamen, gehört aber nicht zur echten Seite dieser Marke.",
        "shortener" to "Verkürzter Link – das echte Ziel ist nicht sichtbar.",
        "deep_subdomain" to "Ungewöhnlich viele Unterdomains – häufig bei Phishing-Seiten.",
        "invalid" to "Das ist keine gültige Webadresse.",
        "eicar" to "Enthält die EICAR-Virentestsignatur (ein harmloser Test, den Virenscanner als Virus melden).",
        "executable" to "Ausführbare Datei (Programm). Die KI öffnet oder startet so etwas nicht.",
        "double_extension" to "Doppelte Dateiendung (z. B. „.pdf.exe“) – klassische Tarnung für Schadprogramme.",
        "magic_mismatch" to "Dateiinhalt passt nicht zur Dateiendung: Ein Programm tarnt sich als harmlose Datei.",
        "dangerous_extension" to "Gefährliche Dateiendung (Programm oder Skript).",
        "macro_document" to "Office-Dokument mit Makros – Makros können Schadcode enthalten.",
        "apk" to "Android-App-Paket (APK). Wird nicht geöffnet.",
        "download_execute" to "Befehl lädt etwas aus dem Netz und führt es sofort aus.",
        "encoded_command" to "Verschleierter (kodierter) Befehl – wird häufig von Schadsoftware benutzt.",
        "destructive_command" to "Befehl, der Daten unwiderruflich löschen kann.",
        "reverse_shell" to "Befehl öffnet eine Fernsteuerung („Reverse Shell“) zu einem fremden Rechner.",
        "script_content" to "Enthält ausführbaren Skriptcode (z. B. <script>, eval).",
        "pdf_script" to "PDF mit eingebettetem Skript oder Startaktion.",
        "prompt_injection" to "Enthält Anweisungen, die versuchen, die KI zu manipulieren (Prompt-Injection).",
        "html_script" to "Enthält eingebetteten Skriptcode (HTML/JavaScript)."
    )

    private val MALICIOUS_CODES: Set<String> = setOf(
        "dangerous_scheme", "eicar", "double_extension", "magic_mismatch", "download_execute",
        "encoded_command", "destructive_command", "reverse_shell"
    )

    // ---------- Muster (mechanisch aus der JS-Referenz) ----------
    private val INJECTION: List<Regex> = listOf(
        Regex("""ignore (all |any |the |your )?(previous|prior|above|earlier|preceding) (instructions|rules|prompts?|directions|messages)"""),
        Regex("""ignoriere (alle |jegliche |die |deine )?(vorherigen |bisherigen |obigen |frueheren |vorigen )?(anweisungen|regeln|instruktionen|vorgaben|befehle)"""),
        Regex("""vergiss (alle |deine |die )?(vorherigen |bisherigen )?(anweisungen|regeln|instruktionen|vorgaben)"""),
        Regex("""(reveal|show|print|leak|repeat|output) (me )?(your|the) (system|hidden|initial) (prompt|instructions?|message)"""),
        Regex("""(gib|zeig|nenn|verrate|wiederhole)\w* (mir )?(deinen|den|dein) (system ?prompt|systemprompt|system anweisungen|geheimen anweisungen)"""),
        Regex("""(du bist jetzt|you are now|tue so als|pretend (to be|you are)) (dan|jailbroken|unrestricted|ohne regeln|without (any )?(rules|restrictions)|in developer mode|im entwicklermodus)"""),
        Regex("""disregard (your|all|any) (safety|guidelines|instructions|rules)"""),
    )
    private val HTML_SCRIPT = Regex("""<\s*script\b|javascript:|\bon(error|load|click)\s*=|<\s*iframe\b""", RegexOption.IGNORE_CASE)
    private val CMD_PATTERNS: List<Pair<String, Regex>> = listOf(
        "download_execute" to Regex("""(curl|wget)\s+[^|;\n]*\|\s*(sudo\s+)?(sh|bash|zsh|python\d?)\b"""),
        "download_execute" to Regex("""powershell[^\n]*(downloadstring|invoke-webrequest|\biwr\b)[^\n]*(iex|invoke-expression)"""),
        "download_execute" to Regex("""certutil[^\n]*-urlcache|bitsadmin[^\n]*\/transfer"""),
        "encoded_command" to Regex("""powershell(\.exe)?\s[^\n]*-(enc|encodedcommand)\b"""),
        "encoded_command" to Regex("""frombase64string[^\n]*(iex|invoke-expression)|(iex|invoke-expression)[^\n]*frombase64string"""),
        "destructive_command" to Regex("""\brm\s+-[a-z]*r[a-z]*f[a-z]*\s+(\/|~|\*|\x24home)(\s|\z)"""),
        "destructive_command" to Regex("""\bformat\s+c:"""),
        "destructive_command" to Regex("""\bdel\s+\/f\s+\/s\s+\/q\s+c:"""),
        "destructive_command" to Regex(""":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:"""),
        "reverse_shell" to Regex("""bash\s+-i\s+>&\s*\/dev\/tcp\/"""),
        "reverse_shell" to Regex("""\/dev\/tcp\/\d+\.\d+\.\d+\.\d+\/\d+"""),
        "reverse_shell" to Regex("""\bnc\s+(-e|-c)\s"""),
        "reverse_shell" to Regex("""socat[^\n]*exec"""),
    )
    private val DOUBLE_RE = Regex("""\.(pdf|doc|docx|xls|xlsx|jpg|jpeg|png|gif|txt|mp3|mp4|zip|rar)\.(exe|scr|bat|cmd|com|msi|vbs|js|jar|ps1|lnk|apk|sh|dll)\z""")

    private val SCRIPT_PATTERNS: List<Regex> = listOf(
        Regex("""<\s*script\b"""),
        Regex("""\beval\s*\("""),
        Regex("""document\.write\s*\(\s*unescape"""),
        Regex("""\bunescape\s*\(""")
    )

    private val SHORTENERS: List<String> = listOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "rebrand.ly", "cutt.ly", "shorturl.at", "tiny.cc", "rb.gy"
    )
    private val BRANDS: Map<String, List<String>> = mapOf(
        "paypal" to listOf("paypal.com", "paypal.me", "paypal.de"),
        "google" to listOf("google.com", "google.de", "googleapis.com", "gstatic.com", "withgoogle.com", "googleusercontent.com", "blog.google"),
        "apple" to listOf("apple.com", "icloud.com"),
        "microsoft" to listOf("microsoft.com"),
        "amazon" to listOf("amazon.com", "amazon.de", "amazon.co.uk", "amazon.fr", "amazon.it", "amazon.es", "amazonaws.com"),
        "facebook" to listOf("facebook.com"),
        "instagram" to listOf("instagram.com"),
        "netflix" to listOf("netflix.com"),
        "sparkasse" to listOf("sparkasse.de"),
        "volksbank" to listOf("volksbank.de"),
        "dhl" to listOf("dhl.de", "dhl.com"),
        "ebay" to listOf("ebay.com", "ebay.de"),
        "steam" to listOf("steampowered.com", "steamcommunity.com"),
        "whatsapp" to listOf("whatsapp.com", "whatsapp.net"),
        "telegram" to listOf("telegram.org"),
        "binance" to listOf("binance.com"),
        "commerzbank" to listOf("commerzbank.de"),
        "postbank" to listOf("postbank.de")
    )
    private val SECOND_LEVEL: List<String> = listOf("co", "com", "org", "net", "gov", "ac")

    private val EXEC_EXT: List<String> = listOf("exe", "dll", "bin", "so", "dex", "elf", "out", "o", "ko", "sys", "com", "msi", "scr")
    private val DANGEROUS_EXT: List<String> = listOf(
        "exe", "scr", "bat", "cmd", "com", "msi", "vbs", "vbe", "jse", "wsf", "ps1", "lnk", "dll", "apk", "jar", "sh", "hta", "reg", "pif"
    )
    private val MACRO_EXT: List<String> = listOf("docm", "xlsm", "pptm", "dotm", "xlam")
    private const val EICAR = "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!"
    private const val MAX_SCAN = 4 * 1024 * 1024

    private val SCHEME_RE = Regex("""^([a-z][a-z0-9+.\-]*):(?!\d)""", RegexOption.IGNORE_CASE)
    private val IPV4_RE = Regex("""^\d{1,3}(\.\d{1,3}){3}\z""")
    private val ZERO_COMBINING = Regex("[\\u0300-\\u036f]")
    private val NON_ALNUM = Regex("[^a-z0-9]+")
    private val GOOGLE_TLD = Regex("""\.google\z""")
    private val APPLE_TLD = Regex("""\.apple\z""")

    private class Item(val code: String, val level: ThreatLevel)

    private fun result(items: List<Item>): ScanResult {
        var level = ThreatLevel.CLEAN
        val codes = ArrayList<String>()
        for (it in items) {
            if (!codes.contains(it.code)) codes.add(it.code)
            if (it.level == MAL) level = MAL
            else if (it.level == SUS && level != MAL) level = SUS
        }
        return ScanResult(level, codes)
    }

    private fun levelOf(code: String): ThreatLevel = if (MALICIOUS_CODES.contains(code)) MAL else SUS

    // ---------- URLs ----------
    private fun registrable(host: String): String {
        val l = host.split('.')
        if (l.size >= 3 && l[l.size - 1].length == 2 && SECOND_LEVEL.contains(l[l.size - 2])) return l.takeLast(3).joinToString(".")
        return l.takeLast(2).joinToString(".")
    }

    fun scanUrl(url: String): ScanResult {
        val u = url.trim()
        val items = ArrayList<Item>()
        val sm = SCHEME_RE.find(u) ?: return result(listOf(Item("invalid", SUS)))
        val scheme = sm.groupValues[1].lowercase()
        if (scheme != "http" && scheme != "https") return result(listOf(Item("dangerous_scheme", MAL)))
        var rest = u.substring(sm.value.length)
        if (!rest.startsWith("//")) return result(listOf(Item("invalid", SUS)))
        rest = rest.substring(2)
        val authority = rest.split('/', '?', '#').first()
        val at = authority.lastIndexOf('@')
        val userinfo: String? = if (at >= 0) authority.substring(0, at) else null
        val hostport = if (at >= 0) authority.substring(at + 1) else authority
        var host: String
        var ipv6 = false
        if (hostport.startsWith("[")) {
            val close = hostport.indexOf(']')
            if (close < 0) return result(listOf(Item("invalid", SUS)))
            host = hostport.substring(1, close)
            ipv6 = true
        } else {
            host = hostport.split(':').first()
        }
        host = host.lowercase()
        if (host.isEmpty()) return result(listOf(Item("invalid", SUS)))
        if (userinfo != null) items.add(Item("userinfo", if (userinfo.contains('.')) MAL else SUS))
        if (ipv6 || IPV4_RE.containsMatchIn(host)) items.add(Item("ip_host", SUS))
        val labels = host.split('.')
        if (labels.any { it.startsWith("xn--") }) items.add(Item("punycode", SUS))
        if (!ipv6) {
            val reg = registrable(host)
            if (SHORTENERS.contains(host) || SHORTENERS.contains(reg)) items.add(Item("shortener", SUS))
            for ((brand, official) in BRANDS) {
                if (host.contains(brand)) {
                    val ok = official.contains(reg) ||
                        (brand == "google" && GOOGLE_TLD.containsMatchIn(host)) ||
                        (brand == "apple" && APPLE_TLD.containsMatchIn(host))
                    if (!ok) items.add(Item("brand_spoof", SUS))
                }
            }
            if (labels.size >= 5) items.add(Item("deep_subdomain", SUS))
        }
        return result(items)
    }

    // ---------- Text (Prompt-Injection, HTML, gefährliche Befehle) ----------
    private fun fold(input: String): String {
        var s = input.lowercase()
        s = s.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
        return ZERO_COMBINING.replace(s, "")
    }

    private fun scanCommands(lower: String, items: MutableList<Item>) {
        for ((code, re) in CMD_PATTERNS) if (re.containsMatchIn(lower)) items.add(Item(code, MAL))
        if (SCRIPT_PATTERNS.any { it.containsMatchIn(lower) }) items.add(Item("script_content", SUS))
    }

    fun scanText(text: String): ScanResult {
        val items = ArrayList<Item>()
        val f = NON_ALNUM.replace(fold(text), " ").trim()
        if (INJECTION.any { it.containsMatchIn(f) }) items.add(Item("prompt_injection", SUS))
        if (HTML_SCRIPT.containsMatchIn(text)) items.add(Item("html_script", SUS))
        scanCommands(text.lowercase(), items)
        return result(items)
    }

    // ---------- Dateien ----------
    private fun magicType(b: ByteArray): String {
        fun at(i: Int): Int = if (b.size > i) (b[i].toInt() and 0xff) else -1
        if (at(0) == 0x4d && at(1) == 0x5a) return "exe"
        if (at(0) == 0x7f && at(1) == 0x45 && at(2) == 0x4c && at(3) == 0x46) return "elf"
        val w = "${at(0)},${at(1)},${at(2)},${at(3)}"
        if (w == "254,237,250,206" || w == "254,237,250,207" || w == "206,250,237,254" ||
            w == "207,250,237,254" || w == "202,254,186,190"
        ) return "macho"
        if (at(0) == 0x64 && at(1) == 0x65 && at(2) == 0x78 && at(3) == 0x0a) return "dex"
        if (at(0) == 0x50 && at(1) == 0x4b && at(2) == 0x03 && at(3) == 0x04) return "zip"
        if (at(0) == 0x25 && at(1) == 0x50 && at(2) == 0x44 && at(3) == 0x46) return "pdf"
        return "other"
    }

    private fun looksText(b: ByteArray): Boolean {
        val n = minOf(b.size, 4096)
        if (n == 0) return true
        var printable = 0
        for (i in 0 until n) {
            val c = b[i].toInt() and 0xff
            if (c == 0) return false
            if (c == 9 || c == 10 || c == 13 || (c in 32..126) || c >= 128) printable++
        }
        return printable.toDouble() / n > 0.85
    }

    fun scanFile(name: String, bytes: ByteArray): ScanResult {
        val items = ArrayList<Item>()
        val nm = name.lowercase().trim()
        val dot = nm.lastIndexOf('.')
        val ext = if (dot >= 0) nm.substring(dot + 1) else ""
        val scan = if (bytes.size > MAX_SCAN) bytes.copyOf(MAX_SCAN) else bytes
        val lat = String(scan, Charsets.ISO_8859_1)

        if (lat.contains(EICAR)) items.add(Item("eicar", MAL))

        val magic = magicType(scan)
        val execMagic = magic == "exe" || magic == "elf" || magic == "macho" || magic == "dex"
        if (DOUBLE_RE.containsMatchIn(nm)) items.add(Item("double_extension", MAL))
        if (execMagic) {
            if (EXEC_EXT.contains(ext) || ext == "") items.add(Item("executable", SUS))
            else if (DANGEROUS_EXT.contains(ext)) items.add(Item("executable", SUS))
            else {
                items.add(Item("executable", SUS))
                items.add(Item("magic_mismatch", MAL))
            }
        }
        if (DANGEROUS_EXT.contains(ext)) items.add(Item("dangerous_extension", SUS))
        if (MACRO_EXT.contains(ext)) items.add(Item("macro_document", SUS))
        if (magic == "zip" && lat.contains("AndroidManifest.xml")) items.add(Item("apk", SUS))
        if (magic == "pdf" && (lat.contains("/JavaScript") || lat.contains("/Launch"))) items.add(Item("pdf_script", SUS))

        if (!execMagic && magic != "zip" && looksText(scan)) {
            val text = String(scan, Charsets.UTF_8)
            val tr = scanText(text.take(1024 * 1024))
            for (c in tr.findings) items.add(Item(c, levelOf(c)))
        }
        return result(items)
    }

    /** Deutsche Erklärung zu einem Befund-Code. */
    fun describe(code: String): String = DESCRIPTIONS[code] ?: code
}
