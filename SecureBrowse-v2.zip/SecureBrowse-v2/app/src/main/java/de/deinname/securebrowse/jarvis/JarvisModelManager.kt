package de.deinname.securebrowse.jarvis

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Phase 2 model-file manager.
 *
 * Imports GGUF files into app-private storage and validates the GGUF header.
 * This does not claim to execute the model; inference requires the native
 * llama.cpp runtime, which is tracked separately in the capability state.
 */
data class GgufModelInfo(
    val fileName: String,
    val filePath: String,
    val sizeBytes: Long,
    val formatVersion: Long,
    val tensorCount: Long,
    val metadataCount: Long
)

data class DeviceAiProfile(
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val appMemoryClassMb: Int,
    val freeStorageBytes: Long,
    /** Free-RAM level below which Android starts killing processes (ActivityManager.MemoryInfo.threshold). */
    val lowMemoryThresholdBytes: Long = 0L
) {
    val recommendedModelClass: String
        get() = when {
            totalRamBytes >= 8L * 1024 * 1024 * 1024 -> "Kleines quantisiertes Modell (ca. 1–3B)"
            totalRamBytes >= 6L * 1024 * 1024 * 1024 -> "Sehr kleines quantisiertes Modell (ca. 1–2B)"
            else -> "Nur sehr kleines Modell; Speicher prüfen"
        }

    /** Grobe Warnung: Die Laufzeit benötigt meist mehr RAM als die GGUF-Datei groß ist. */
    fun warnsAboutSize(modelBytes: Long): Boolean = modelBytes > 0 && modelBytes > totalRamBytes / 2
}

class JarvisModelManager(private val context: Context) {
    private val modelDirectory = File(context.filesDir, "jarvis/models").apply { mkdirs() }
    private val preferences = context.getSharedPreferences("jarvis_model", Context.MODE_PRIVATE)

    fun deviceProfile(): DeviceAiProfile {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)
        return DeviceAiProfile(
            totalRamBytes = memory.totalMem,
            availableRamBytes = memory.availMem,
            appMemoryClassMb = activityManager.memoryClass,
            freeStorageBytes = StatFs(context.filesDir.absolutePath).availableBytes,
            lowMemoryThresholdBytes = memory.threshold
        )
    }

    fun installedModel(): GgufModelInfo? {
        val path = preferences.getString(KEY_MODEL_PATH, null) ?: return null
        val file = File(path)
        if (!file.isFile || !file.canRead()) return null
        return runCatching { inspect(file) }.getOrNull()
    }

    suspend fun importGguf(uri: Uri, onProgress: (Long) -> Unit = {}): GgufModelInfo = withContext(Dispatchers.IO) {
        val displayName = queryDisplayName(uri) ?: "jarvis-model.gguf"
        require(displayName.lowercase(Locale.ROOT).endsWith(".gguf")) {
            "Bitte eine GGUF-Modelldatei auswählen."
        }

        val sourceSize = querySize(uri)
        val freeSpace = StatFs(modelDirectory.absolutePath).availableBytes
        if (sourceSize != null) {
            require(sourceSize <= freeSpace && freeSpace - sourceSize >= MIN_FREE_SPACE_AFTER_IMPORT) {
                "Nicht genug freier Speicher: Datei ${formatBytesStatic(sourceSize)}, frei ${formatBytesStatic(freeSpace)}. Mindestens 200 MB sollen frei bleiben."
            }
        }

        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val destination = File(modelDirectory, safeName)
        val temporary = File(modelDirectory, "$safeName.importing")
        try {
            var copied = 0L
            var lastProgressReport = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                temporary.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        copied += count
                        if (copied - lastProgressReport >= PROGRESS_UPDATE_BYTES) {
                            onProgress(copied)
                            lastProgressReport = copied
                        }
                        if (copied > freeSpace || freeSpace - copied < MIN_FREE_SPACE_AFTER_IMPORT) {
                            error("Import abgebrochen: Es müssen mindestens 200 MB Gerätespeicher frei bleiben.")
                        }
                    }
                }
            } ?: error("Die ausgewählte Datei konnte nicht geöffnet werden.")

            onProgress(copied)
            val info = inspect(temporary)
            if (destination.exists()) destination.delete()
            check(temporary.renameTo(destination)) { "Modelldatei konnte nicht gespeichert werden." }
            val installed = info.copy(fileName = destination.name, filePath = destination.absolutePath, sizeBytes = destination.length())
            preferences.edit().putString(KEY_MODEL_PATH, destination.absolutePath).apply()
            installed
        } catch (error: Exception) {
            temporary.delete()
            throw error
        }
    }

    private fun querySize(uri: Uri): Long? {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (index >= 0 && !cursor.isNull(index)) return cursor.getLong(index)
                }
            }
        return null
    }

    suspend fun removeModel() = withContext(Dispatchers.IO) {
        val path = preferences.getString(KEY_MODEL_PATH, null)
        if (path != null) File(path).delete()
        preferences.edit().remove(KEY_MODEL_PATH).apply()
    }

    private fun queryDisplayName(uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) return cursor.getString(index)
                }
            }
        return uri.lastPathSegment
    }

    private fun inspect(file: File): GgufModelInfo {
        require(file.length() >= 24L) { "Datei ist zu klein und kein gültiges GGUF-Modell." }
        RandomAccessFile(file, "r").use { input ->
            val magic = ByteArray(4)
            input.readFully(magic)
            require(String(magic, Charsets.US_ASCII) == "GGUF") {
                "Ungültiges Dateiformat: GGUF-Datei erwartet."
            }
            val version = readUInt32(input)
            require(version in 2L..3L) { "Nicht unterstützte GGUF-Version: $version" }
            val tensors = readUInt64(input)
            val metadata = readUInt64(input)
            require(tensors in 1L..10_000_000L && metadata in 1L..1_000_000L) {
                "GGUF-Kopfzeile enthält ungültige Werte."
            }
            return GgufModelInfo(file.name, file.absolutePath, file.length(), version, tensors, metadata)
        }
    }

    private fun readUInt32(input: RandomAccessFile): Long {
        var value = 0L
        repeat(4) { value = value or (input.readUnsignedByte().toLong() shl (it * 8)) }
        return value
    }

    private fun readUInt64(input: RandomAccessFile): Long {
        var value = 0L
        repeat(8) { value = value or (input.readUnsignedByte().toLong() shl (it * 8)) }
        return value
    }

    companion object {
        private const val KEY_MODEL_PATH = "installed_model_path"
        private const val MIN_FREE_SPACE_AFTER_IMPORT = 200L * 1024 * 1024
        private const val PROGRESS_UPDATE_BYTES = 1024L * 1024
    }
}

private fun formatBytesStatic(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    do { value /= 1024.0; unit++ } while (value >= 1024.0 && unit < units.lastIndex)
    return String.format(Locale.ROOT, "%.1f %s", value, units[unit])
}
