package de.deinname.securebrowse.jarvis

import android.app.ActivityManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

sealed interface JarvisEngineState {
    data object Unloaded : JarvisEngineState
    data object Loading : JarvisEngineState
    data class Ready(val modelName: String, val contextSize: Int, val threads: Int) : JarvisEngineState
    data class Failed(val message: String) : JarvisEngineState
}

enum class JarvisStopReason(val label: String) {
    FINISHED("Antwort vollständig."),
    MAX_TOKENS("Antwort wegen der Längenbegrenzung gekürzt."),
    CANCELLED("Abgebrochen."),
    TIMEOUT("Abgebrochen: Zeitlimit erreicht."),
    LOW_MEMORY("Abgebrochen: Arbeitsspeicher wird knapp.")
}

sealed interface JarvisEvent {
    data class Token(val text: String) : JarvisEvent
    data class Done(val reason: JarvisStopReason) : JarvisEvent
}

data class GenerationOptions(
    val maxNewTokens: Int = 512,
    val timeoutMs: Long = 180_000L
)

class JarvisInferenceException(message: String) : Exception(message)

/**
 * Runs the native llama.cpp runtime.
 *
 *  - All native calls run on ONE dedicated thread, so load/generate/unload can never overlap.
 *  - [cancel] is lock-free and stops a running answer within one token (or within one graph node
 *    during prompt processing).
 *  - Memory protection: pre-load check ([MemoryGuard]), KV cache sized to the budget, periodic
 *    low-memory check while generating, and automatic cancel + unload on system memory pressure.
 */
class LlamaInferenceEngine(
    context: Context,
    private val modelManager: JarvisModelManager
) : JarvisInferenceEngine {

    private val appContext = context.applicationContext
    private val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val executor = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "jarvis-inference") }
    private val inferenceDispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow<JarvisEngineState>(JarvisEngineState.Unloaded)
    val state: StateFlow<JarvisEngineState> = _state

    override val modelName: String?
        get() = (_state.value as? JarvisEngineState.Ready)?.modelName

    val isNativeAvailable: Boolean get() = LlamaBridge.isLibraryLoaded

    /** Set when the system asked for memory back; makes a running answer stop with LOW_MEMORY. */
    private val memoryPressure = AtomicBoolean(false)

    private val memoryCallbacks = object : ComponentCallbacks2 {
        override fun onTrimMemory(level: Int) {
            // 40 = TRIM_MEMORY_BACKGROUND and above: process is a kill candidate -> free everything.
            // 15 = TRIM_MEMORY_RUNNING_CRITICAL (not delivered on newer Android, still used on older).
            if (level >= 40 || level == 15) releaseUnderPressure()
        }

        override fun onLowMemory() = releaseUnderPressure()
        override fun onConfigurationChanged(newConfig: Configuration) = Unit
    }

    init {
        appContext.registerComponentCallbacks(memoryCallbacks)
    }

    private fun releaseUnderPressure() {
        if (_state.value !is JarvisEngineState.Ready) return
        memoryPressure.set(true)
        cancel()
        scope.launch {
            unload()
            _state.value = JarvisEngineState.Failed("Modell wegen knappen Arbeitsspeichers entladen. Bitte erneut laden.")
        }
    }

    override suspend fun isReady(): Boolean = _state.value is JarvisEngineState.Ready

    /** Loads the installed GGUF model. Throws [JarvisInferenceException] with a user-readable message. */
    suspend fun load() {
        _state.value = JarvisEngineState.Loading
        try {
            if (!LlamaBridge.isLibraryLoaded) {
                throw JarvisInferenceException(
                    "Die native llama.cpp-Bibliothek ist in diesem Build nicht enthalten (nur arm64-Geräte, llama.cpp muss eingebunden sein)."
                )
            }
            val model = modelManager.installedModel()
                ?: throw JarvisInferenceException("Kein Modell installiert.")
            val profile = modelManager.deviceProfile()

            val plan = MemoryGuard.plan(
                modelBytes = model.sizeBytes,
                totalRamBytes = profile.totalRamBytes,
                availableRamBytes = profile.availableRamBytes,
                lowMemoryThresholdBytes = profile.lowMemoryThresholdBytes
            )
            val allowed = when (plan) {
                is MemoryGuard.Plan.Refused -> throw JarvisInferenceException(plan.reason)
                is MemoryGuard.Plan.Allowed -> plan
            }

            val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)
            memoryPressure.set(false)
            val contextSize = withContext(inferenceDispatcher) {
                if (!LlamaBridge.nativeCpuSupported()) {
                    throw JarvisInferenceException("Dieser Prozessor unterstützt die benötigten ARM-Befehle (dotprod) nicht.")
                }
                LlamaBridge.nativeLoad(model.filePath, allowed.maxContext, threads, allowed.kvBudgetBytes)
            }
            if (contextSize <= 0) throw JarvisInferenceException(loadErrorMessage(contextSize))
            _state.value = JarvisEngineState.Ready(model.fileName, contextSize, threads)
        } catch (e: CancellationException) {
            _state.value = JarvisEngineState.Unloaded
            throw e
        } catch (e: JarvisInferenceException) {
            _state.value = JarvisEngineState.Failed(e.message ?: "Modell konnte nicht geladen werden.")
            throw e
        } catch (e: Throwable) {
            val wrapped = JarvisInferenceException("Modell konnte nicht geladen werden: ${e.message}")
            _state.value = JarvisEngineState.Failed(wrapped.message!!)
            throw wrapped
        }
    }

    /** Stops a running answer (if any), then frees the model and its memory. Safe to call at any time. */
    suspend fun unload() {
        if (!LlamaBridge.isLibraryLoaded) return
        cancel()
        withContext(inferenceDispatcher) { LlamaBridge.nativeUnload() }
        _state.value = JarvisEngineState.Unloaded
    }

    /** Aborts the running generation. The stream then ends with [JarvisStopReason.CANCELLED]. */
    override fun cancel() {
        if (LlamaBridge.isLibraryLoaded) LlamaBridge.nativeCancel()
    }

    override suspend fun generate(prompt: String, conversation: List<JarvisMessage>): String {
        val text = StringBuilder()
        stream(conversation + JarvisMessage("user", prompt)).collect { event ->
            if (event is JarvisEvent.Token) text.append(event.text)
        }
        return text.toString()
    }

    /**
     * Streams the answer. [conversation] must end with the new user message. Cancelling the
     * collector also cancels the native generation.
     */
    fun stream(
        conversation: List<JarvisMessage>,
        systemPrompt: String? = DEFAULT_SYSTEM_PROMPT,
        options: GenerationOptions = GenerationOptions()
    ): Flow<JarvisEvent> = channelFlow {
        if (_state.value !is JarvisEngineState.Ready) {
            throw JarvisInferenceException("Das Modell ist nicht geladen.")
        }
        val messages = buildList {
            if (!systemPrompt.isNullOrBlank()) add(JarvisMessage("system", systemPrompt))
            addAll(conversation.filter { it.role in ALLOWED_ROLES && it.content.isNotBlank() })
        }
        if (messages.none { it.role == "user" }) throw JarvisInferenceException("Keine Nutzernachricht vorhanden.")
        val roles = messages.map { it.role }.toTypedArray()
        val contents = messages.map { it.content.toByteArray(Charsets.UTF_8) }.toTypedArray()

        memoryPressure.set(false)
        var lowMemory = false
        var tokenCount = 0
        var completed = false

        val code = try {
            withContext(inferenceDispatcher) {
                LlamaBridge.nativeGenerate(
                    roles, contents, options.maxNewTokens.coerceIn(1, 2048), options.timeoutMs,
                    TokenCallback { bytes ->
                        if (!isActive) return@TokenCallback false
                        trySend(JarvisEvent.Token(String(bytes, Charsets.UTF_8)))
                        tokenCount++
                        if (tokenCount % 16 == 0 && (memoryPressure.get() || isMemoryCritical())) {
                            lowMemory = true
                            return@TokenCallback false
                        }
                        true
                    }
                )
            }.also { completed = true }
        } finally {
            // withContext resumes with CancellationException right away when the collector goes away,
            // while the native call may still be busy (e.g. processing the prompt): tell it to stop.
            if (!completed) LlamaBridge.nativeCancel()
        }

        if (code < 0) throw JarvisInferenceException(generateErrorMessage(code))
        val reason = when {
            lowMemory || memoryPressure.get() -> JarvisStopReason.LOW_MEMORY
            code == LlamaBridge.STOP_EOS -> JarvisStopReason.FINISHED
            code == LlamaBridge.STOP_MAX_TOKENS -> JarvisStopReason.MAX_TOKENS
            code == LlamaBridge.STOP_TIMEOUT -> JarvisStopReason.TIMEOUT
            else -> JarvisStopReason.CANCELLED
        }
        send(JarvisEvent.Done(reason))
    }.buffer(Channel.UNLIMITED)

    private fun isMemoryCritical(): Boolean {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return info.lowMemory || info.availMem < info.threshold
    }

    private fun loadErrorMessage(code: Int): String {
        val detail = LlamaBridge.nativeLastError()
        val base = when (code) {
            LlamaBridge.ERR_MODEL_LOAD -> "Die Modelldatei konnte nicht geladen werden (nicht unterstützte Architektur oder Quantisierung, beschädigte Datei oder zu wenig Speicher)."
            LlamaBridge.ERR_CONTEXT -> "Der Kontext konnte nicht angelegt werden (vermutlich zu wenig Speicher)."
            LlamaBridge.ERR_KV_BUDGET -> "Selbst der kleinste Kontext passt nicht in den verfügbaren Speicher. Bitte ein kleineres Modell wählen."
            else -> "Unbekannter Ladefehler ($code)."
        }
        return if (detail.isBlank()) base else "$base [$detail]"
    }

    private fun generateErrorMessage(code: Int): String {
        val detail = LlamaBridge.nativeLastError()
        val base = when (code) {
            LlamaBridge.ERR_NOT_LOADED -> "Das Modell ist nicht geladen."
            LlamaBridge.ERR_PROMPT_TOO_LONG -> "Die Nachricht ist für das Kontextfenster zu lang. Bitte kürzen."
            LlamaBridge.ERR_TEMPLATE -> "Das Chat-Format des Modells konnte nicht angewendet werden."
            LlamaBridge.ERR_TOKENIZE -> "Der Text konnte nicht in Tokens zerlegt werden."
            LlamaBridge.ERR_DECODE -> "Die Berechnung ist fehlgeschlagen."
            else -> "Interner Fehler ($code)."
        }
        return if (detail.isBlank()) base else "$base [$detail]"
    }

    companion object {
        private val ALLOWED_ROLES = setOf("user", "assistant")
        const val DEFAULT_SYSTEM_PROMPT =
            "Du bist JARVIS, ein hilfreicher Assistent in der App SecureBrowse. Antworte knapp und auf Deutsch, sofern nicht anders gewünscht."
    }
}
