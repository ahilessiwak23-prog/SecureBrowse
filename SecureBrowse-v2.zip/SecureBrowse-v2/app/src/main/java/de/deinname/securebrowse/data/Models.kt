package de.deinname.securebrowse.data

data class Bookmark(val url: String, val title: String, val createdAt: Long)

data class HistoryEntry(val url: String, val title: String, val visitedAt: Long)

data class SavedTab(val id: Long, val url: String, val title: String)

data class SavedTabs(val tabs: List<SavedTab>, val selectedId: Long?)

/** [template] contains exactly one "%s" that is replaced by the URL-encoded query. */
data class SearchEngine(val id: String, val name: String, val template: String)

object SearchEngines {
    val DuckDuckGo = SearchEngine("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q=%s")
    val all: List<SearchEngine> = listOf(
        DuckDuckGo,
        SearchEngine("brave", "Brave Search", "https://search.brave.com/search?q=%s"),
        SearchEngine("mojeek", "Mojeek", "https://www.mojeek.com/search?q=%s")
    )

    fun byId(id: String?): SearchEngine = all.firstOrNull { it.id == id } ?: DuckDuckGo
}
