package de.deinname.securebrowse.jarvis

/** Called from native code for every chunk of generated text (UTF-8 bytes). Return false to stop. */
fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

/**
 * Thin JNI surface. All logic lives in [LlamaInferenceEngine]; native code is in src/main/cpp.
 * The library only exists if llama.cpp was added (tools/add-llama-cpp.sh) and the app was built for
 * arm64-v8a. Everything else (emulator, x86) gets [isLibraryLoaded] == false and JARVIS reports that
 * instead of crashing.
 */
object LlamaBridge {
    val isLibraryLoaded: Boolean = try {
        System.loadLibrary("jarvis_llama")
        true
    } catch (_: UnsatisfiedLinkError) {
        false
    }

    /** True if the CPU has the dot-product extension the native build requires (armv8.2-a+dotprod). */
    external fun nativeCpuSupported(): Boolean

    /** Loads the model. Returns the actual context size (>0) or a negative error code. */
    external fun nativeLoad(path: String, nCtxCap: Int, nThreads: Int, kvBudgetBytes: Long): Int
    external fun nativeUnload()

    /** Lock-free and safe to call from any thread, also while [nativeGenerate] is running. */
    external fun nativeCancel()
    external fun nativeLastError(): String

    /** Returns a STOP_* code (>= 0) or a negative error code. Blocks until the answer is complete. */
    external fun nativeGenerate(
        roles: Array<String>,
        contents: Array<ByteArray>,
        maxNewTokens: Int,
        timeoutMs: Long,
        callback: TokenCallback
    ): Int

    // Mirrors of the constants in jarvis_jni.cpp
    const val STOP_EOS = 0
    const val STOP_MAX_TOKENS = 1
    const val STOP_CANCELLED = 2
    const val STOP_TIMEOUT = 3
    const val ERR_NOT_LOADED = -1
    const val ERR_PROMPT_TOO_LONG = -2
    const val ERR_TEMPLATE = -3
    const val ERR_TOKENIZE = -4
    const val ERR_DECODE = -5
    const val ERR_JNI = -6
    const val ERR_MODEL_LOAD = -10
    const val ERR_CONTEXT = -11
    const val ERR_KV_BUDGET = -12
}
