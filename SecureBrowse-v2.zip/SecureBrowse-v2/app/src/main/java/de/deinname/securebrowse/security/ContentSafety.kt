package de.deinname.securebrowse.security

import java.text.Normalizer

/**
 * Ergebnis einer Prüfung. [category] ist "weapons", "drugs" oder null.
 * [message] ist die freundliche Ablehnung (leer, wenn nicht blockiert).
 */
data class SafetyVerdict(val blocked: Boolean, val category: String?, val message: String)

/**
 * ContentSafety – Schutz vor Anleitungen zu illegalen Waffen/Sprengstoff und harten Drogen.
 *
 * Ehrlich: Das ist ein lokaler Mustererkenner (Heuristik), kein Allheilmittel. Er fängt die typischen
 * "Wie baue/koche/kaufe ich …"-Anfragen (Deutsch + Englisch) ab, erlaubt aber Aufklärung, Geschichte,
 * Waffenrecht, Hilfe bei Sucht usw. Komplett buchstabenweise getippte Sätze ("w i e k o c h e …") erkennt er nicht.
 *
 * 1:1-Port von web/src/js/10-safety.js. Die Regex-Muster unten sind mechanisch aus der JS-Datei übernommen
 * (tools: scratchpad gen_patterns.py); Änderungen immer zuerst in der JS-Referenz + tests/vectors/safety.json machen.
 * Reines Kotlin (keine android.*-Imports), damit es auf der JVM getestet werden kann.
 */
object ContentSafety {
    const val CATEGORY_WEAPONS = "weapons"
    const val CATEGORY_DRUGS = "drugs"

    const val MESSAGE_WEAPONS: String =
        "Dabei kann ich dir nicht helfen: Anleitungen zum Bau oder Kauf illegaler Waffen und Sprengstoffe gebe ich nicht. " +
            "Ich erkläre dir aber gern die Geschichte, das Waffenrecht oder Sicherheitsthemen."

    const val MESSAGE_DRUGS: String =
        "Dabei kann ich dir nicht helfen: Herstellung, Kauf oder Handel mit illegalen Drogen unterstütze ich nicht. " +
            "Wenn du Fragen zu Wirkung, Risiken oder Hilfe bei Sucht hast, helfe ich gern. " +
            "Hilfe findest du bei einer Suchtberatungsstelle in deiner Nähe oder bei der Telefonseelsorge (0800 111 0 111, kostenlos)."

    // ---------- Wortlisten (mechanisch aus der JS-Referenz) ----------
    private val EXPLOSIVE_NOUN = Regex("""\b(bombe|bomben|rohrbombe|nagelbombe|autobombe|paketbombe|sprengstoff|sprengstoffe|sprengsatz|sprengkoerper|sprengladung|handgranate|handgranaten|granate|zuender|zuendmechanismus|molotow|molotov|molotowcocktail|molotovcocktail|brandsatz|napalm|thermit|tnt|c4|semtex|pipe bomb|explosive|explosives|explosive device|detonator|grenade|bomb|bombs|dirty bomb|ied)\b""")
    private val GUN_NOUN = Regex("""\b(pistole|revolver|gewehr|waffe|waffen|schusswaffe|schusswaffen|maschinenpistole|sturmgewehr|kalaschnikow|schalldaempfer|ghost gun|ghostgun|silencer|suppressor|firearm|firearms|gun|guns|rifle|pistol|weapon|weapons)\b""")
    private val STRONG_BUILD = Regex("""\b(bau|baue|bauen|baut|bauanleitung|zusammenbauen|zusammenbau|basteln|bastle|bastelt|herstellen|herstellung|anfertigen|anfertigung|fertigen|produzieren|produziere|produktion|konstruieren|konstruiere|make|making|build|building|create|craft|assemble|manufacture|manufacturing|produce|construct|synthesize|synthesise)\b""")
    private val WEAK_BUILD = Regex("""\b(mache|machen|macht|kochen|mischen|zusammenmischen|anleitung|recipe|tutorial|instructions|diy|selber|selbst|zuhause|at home)\b""")
    private val ILLEGAL_CUE = Regex("""\b(illegal\w*|darknet|dark web|darkweb|schwarzmarkt|black market|untraceable|unregistered|nicht rueckverfolgbar|unter der hand|schwarz kaufen)\b|\bohne (waffenschein|waffenbesitzkarte|erlaubnis|lizenz|license|licence|background check|registrierung|ausweis|kontrolle|papiere)\b|\bwithout (a )?(license|licence|background check|permit|registration|papers)\b""")
    private val ACQUIRE = Regex("""\b(kaufen|kaufe|kauf|bestellen|bestelle|besorgen|besorge|beschaffen|organisieren|buy|order|purchase|acquire|get)\b""")
    private val ACQUIRE_PHRASE = Regex("""\b(komme ich an|wo gibt es|wo bekomme|wo kriege|an eine waffe kommen)\b""")
    private val GAME_CUE = Regex("""\b(minecraft|fortnite|roblox|terraria|gta|lego|call of duty|warzone|battlefield|valorant|counter strike|fallout|skyrim|zelda|bath bomb|bade bombe|photo bomb|foto bombe)\b""")
    private val REAL_CUE = Regex("""\b(echt|echte|echten|real life|in echt|wirklich|irl|really)\b""")
    private val HISTORY_CUE = Regex("""\b(geschichte|historisch\w*|history|historical|weltkrieg|wwii|ww2|mittelalter|manhattan|winterkrieg|museum|film|dokumentation|erfunden|erfinder)\b""")
    private val INSTRUCTION_CUE = Regex("""\b(anleitung|schritt fuer schritt|step by step|tutorial|how to|zuhause|zu hause|at home|selbst|selber|diy|recipe|zutaten|materialien|was brauche ich)\b""")
    private val AUTOMATIC = Regex("""\b(vollautomat\w*|full auto\w*|dauerfeuer|automatikfeuer)\b""")
    private val CONVERT_VERB = Regex("""\b(umbau\w*|umruest\w*|modifi\w*|convert\w*|bau\w*|aender\w*|umwandel\w*|freischalten|um)\b""")
    private val DECO_WEAPON = Regex("""\b(dekowaffe|deko waffe|dekorationswaffe|deko pistole|deko gewehr|deko revolver)\b""")
    private val REACTIVATE = Regex("""\b(scharf|reaktivier\w*|funktionsfaehig|schussfaehig|wiederherstell\w*|umbau\w*)\b""")
    private val THREE_D = Regex("""\b(3d|dreid|3 d)\b""")
    private val MODEL_CUE = Regex("""\b(modell|miniatur\w*|figur|spielfigur|spielzeug|cosplay|requisite|prop|toy|model|miniature|figurine)\b""")
    private val FUNCTIONAL_CUE = Regex("""\b(funktionsfaehig|schussfaehig|scharf|functional|working|firing|schiessen|shoot|echt|echte|real)\b""")
    private val CHEMBIO_AGENT = Regex("""\b(sarin|tabun|vx|senfgas|nervengas|nerve agent|nervenkampfstoff|anthrax|milzbrand|rizin|ricin|biowaffe|bioweapon|chemiewaffe|chemical weapon|kampfstoff|botulinum)\b""")
    private val CHEMBIO_VERB = Regex("""\b(herstell\w*|synthetisier\w*|synthesi[sz]e|zuecht\w*|kultivier\w*|produzier\w*|make|synthesis|produce|cultivate|grow|weaponi[sz]e|waffenfaehig|extrahier\w*|isolier\w*|brew|brauen|braue)\b""")
    private val HARD_DRUG = Regex("""\b(meth|methamphetamin\w*|crystal|crystal meth|heroin|kokain|cocain\w*|cocaine|koks|crack|mdma|ecstasy|xtc|lsd|fentanyl\w*|amphetamin\w*|ketamin|ghb|dmt|opium|psilocybin\w*|zauberpilz\w*|magic mushroom\w*|pcp|mescalin\w*|meskalin\w*|designerdroge\w*)\b""")
    private val ANY_DRUG = Regex("""\b(meth|methamphetamin\w*|crystal|crystal meth|heroin|kokain|cocain\w*|cocaine|koks|crack|mdma|ecstasy|xtc|lsd|fentanyl\w*|amphetamin\w*|ketamin|ghb|dmt|opium|psilocybin\w*|zauberpilz\w*|magic mushroom\w*|pcp|mescalin\w*|meskalin\w*|designerdroge\w*|drogen|droge|drugs|drug|betaeubungsmittel)\b""")
    private val GENERIC_DRUG = Regex("""\b(drogen|droge|drugs|drug|betaeubungsmittel)\b""")
    private val DRUG_SYNTH = Regex("""\b(koche|kochen|kocht|kochst|cook|brauen|braue|brew|herstell\w*|synthetisier\w*|synthesi[sz]e|synthesis|produzier\w*|produce|make|extrahier\w*|extract|isolier\w*|anbau\w*|anbauen|anpflanzen|grow|cultivate|zuecht\w*|kultivier\w*|manufacture|bau|baue|bauen|baut|zusammenmischen|anleitung|tutorial|instructions|recipe)\b""")
    private val DRUG_ACQUIRE = Regex("""\b(kaufen|kaufe|kauf|bestellen|bestelle|besorgen|besorge|beschaffen|buy|order|purchase)\b""")
    private val DRUG_ACQUIRE_PHRASE = Regex("""\b(komme ich an|wo gibt es|wo bekomme|wo kriege)\b""")
    private val DRUG_CUE = Regex("""\b(darknet|dark web|darkweb|dealer|strasse|schwarzmarkt|anonym|ohne erwischt|untergrund)\b""")
    private val DRUG_DEAL = Regex("""\b(verkauf\w*|dealen|deale|schmuggel\w*|schmuggle\w*|vertreiben|sell|smuggle\w*|traffick\w*|strecken|strecke|streck\w*)\b""")
    private val LEGAL_CUE = Regex("""\b(strafbar|strafe|strafen|strafrecht|rechtslage|rechtlich\w*|gesetz\w*|was passiert|was droht|law|legal status)\b""")
    private val STRONG_SYNTH = Regex("""\b(koche|kochen|kocht|kochst|cook|brauen|braue|brew|herstell\w*|synthetisier\w*|synthesi[sz]e|synthesis|produzier\w*|produce|make|extrahier\w*|extract|isolier\w*|anbau\w*|anpflanzen|grow|cultivate|zuecht\w*|kultivier\w*|manufacture|bau|baue|bauen|baut|zusammenmischen)\b""")

    private val STELL = Regex("""\bstell\w*\b""")
    private val HER = Regex("""\bher\b""")
    private val ZERO_WIDTH = Regex("[\\u200b-\\u200f\\u2060\\ufeff]")
    private val COMBINING = Regex("[\\u0300-\\u036f]")
    private val NON_ALNUM = Regex("[^a-z0-9]+")
    private val SINGLES = Regex("(?:^| )((?:[a-z0-9] ){2,}[a-z0-9])(?= |\\z)")

    private class Hit(val category: String, val rule: String)

    // ---------- Normalisierung ----------
    private fun fold(input: String): String {
        var s = input.lowercase()
        s = ZERO_WIDTH.replace(s, "")
        s = s.replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
        return COMBINING.replace(s, "")
    }

    private fun plainForm(s: String): String = NON_ALNUM.replace(fold(s), " ").trim()

    private fun leetForm(s: String): String {
        val f = fold(s)
        val sb = StringBuilder(f.length)
        for (c in f) {
            sb.append(
                when (c) {
                    '0' -> 'o'
                    '1' -> 'i'
                    '3' -> 'e'
                    '4' -> 'a'
                    '5' -> 's'
                    '7' -> 't'
                    '@' -> 'a'
                    '$' -> 's'
                    else -> c
                }
            )
        }
        return NON_ALNUM.replace(sb.toString(), " ").trim()
    }

    /** "b o m b e" / "B.O.M.B.E" -> "bombe": Folgen aus mindestens 3 einzelnen Zeichen werden zusammengezogen. */
    private fun joinSingles(s: String): String =
        SINGLES.replace(s) { m ->
            (if (m.value[0] == ' ') " " else "") + m.groupValues[1].replace(" ", "")
        }

    // ---------- Hilfsfunktionen ----------
    /** Token-Indizes aller Treffer (Tokens sind durch genau ein Leerzeichen getrennt). */
    private fun idxs(str: String, re: Regex): List<Int> =
        re.findAll(str).map { m -> str.substring(0, m.range.first).count { it == ' ' } }.toList()

    private fun near(a: List<Int>, b: List<Int>, d: Int): Boolean {
        for (x in a) for (y in b) if (kotlin.math.abs(x - y) <= d) return true
        return false
    }

    private fun has(str: String, re: Regex): Boolean = re.containsMatchIn(str)

    private fun buildPositions(str: String): List<Int> {
        var p = idxs(str, STRONG_BUILD)
        if (has(str, STELL)) p = p + idxs(str, HER)
        return p
    }

    private fun evaluate(str: String): Hit? {
        if (str.isEmpty()) return null
        val gameExempt = has(str, GAME_CUE) && !has(str, REAL_CUE)

        val exp = idxs(str, EXPLOSIVE_NOUN)
        val gun = idxs(str, GUN_NOUN)
        val anyNoun = exp + gun
        val strong = buildPositions(str)

        // W1: Bau/Herstellung von Waffen/Sprengstoff
        if (!gameExempt) {
            val w1 = near(anyNoun, strong, 8) || near(exp, idxs(str, WEAK_BUILD), 6)
            if (w1 && !(has(str, HISTORY_CUE) && !has(str, INSTRUCTION_CUE))) return Hit(CATEGORY_WEAPONS, "W1")
        }
        // W2: illegaler Erwerb
        if (anyNoun.isNotEmpty()) {
            val acq = idxs(str, ACQUIRE) + idxs(str, ACQUIRE_PHRASE)
            if (acq.isNotEmpty() && has(str, ILLEGAL_CUE) && near(anyNoun, acq, 10)) return Hit(CATEGORY_WEAPONS, "W2")
        }
        // W3: Umbau auf Vollautomatik / Dekowaffe scharf machen
        if (has(str, AUTOMATIC) && has(str, CONVERT_VERB)) return Hit(CATEGORY_WEAPONS, "W3")
        if (has(str, DECO_WEAPON) && has(str, REACTIVATE)) return Hit(CATEGORY_WEAPONS, "W3")
        // W4: Chemie-/Biowaffen
        val agents = idxs(str, CHEMBIO_AGENT)
        if (agents.isNotEmpty() && near(agents, idxs(str, CHEMBIO_VERB), 8)) return Hit(CATEGORY_WEAPONS, "W4")
        // W5: 3D-gedruckte Waffen
        if (!gameExempt && gun.isNotEmpty() && near(gun, idxs(str, THREE_D), 6) &&
            !(has(str, MODEL_CUE) && !has(str, FUNCTIONAL_CUE))
        ) {
            return Hit(CATEGORY_WEAPONS, "W5")
        }

        // D1: Herstellung harter Drogen
        val hard = idxs(str, HARD_DRUG)
        val anyDrug = idxs(str, ANY_DRUG)
        var synth = idxs(str, DRUG_SYNTH)
        if (has(str, STELL)) synth = synth + idxs(str, HER)
        if (near(anyDrug, synth, 8)) {
            // "anleitung/tutorial/instructions/recipe" allein zählen nur bei harten Drogen
            var strongSynth = idxs(str, STRONG_SYNTH)
            if (has(str, STELL)) strongSynth = strongSynth + idxs(str, HER)
            if (near(anyDrug, strongSynth, 8) || near(hard, synth, 8)) return Hit(CATEGORY_DRUGS, "D1")
        }
        // D2: Erwerb
        val dacq = idxs(str, DRUG_ACQUIRE) + idxs(str, DRUG_ACQUIRE_PHRASE)
        if (dacq.isNotEmpty()) {
            if (near(hard, dacq, 8)) return Hit(CATEGORY_DRUGS, "D2")
            if (near(idxs(str, GENERIC_DRUG), dacq, 8) && has(str, DRUG_CUE)) return Hit(CATEGORY_DRUGS, "D2")
        }
        // D3: Handel/Schmuggel/Strecken
        if (!has(str, LEGAL_CUE) && near(anyDrug, idxs(str, DRUG_DEAL), 8)) return Hit(CATEGORY_DRUGS, "D3")
        return null
    }

    /** Prüft einen Text (Nutzereingabe oder KI-Antwort). Blockiert nur bei klaren Anleitungs-/Beschaffungsmustern. */
    fun check(text: String): SafetyVerdict {
        val plain = plainForm(text)
        val leet = leetForm(text)
        val forms = listOf(plain, leet, joinSingles(plain), joinSingles(leet))
        var hit: Hit? = null
        for (i in forms.indices) {
            if (hit != null) break
            if (forms.indexOf(forms[i]) == i) hit = evaluate(forms[i]) // gleiche Formen nur einmal prüfen
        }
        val h = hit ?: return SafetyVerdict(false, null, "")
        val msg = if (h.category == CATEGORY_WEAPONS) MESSAGE_WEAPONS else MESSAGE_DRUGS
        return SafetyVerdict(true, h.category, msg)
    }
}
