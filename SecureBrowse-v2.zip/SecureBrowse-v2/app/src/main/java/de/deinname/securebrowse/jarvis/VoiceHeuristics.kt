package de.deinname.securebrowse.jarvis

/**
 * Rät das Geschlecht einer TTS-Stimme anhand ihres Namens und wählt eine passende Stimme.
 * Reines Kotlin (keine Android-Typen) – 1:1-Port von web/src/js/13-voice.js.
 *
 * Ehrlich: Android liefert KEIN offizielles Geschlecht. Unbekannte Namen => "unknown"; dann verschiebt
 * JARVIS die Tonhöhe, damit „männlich/weiblich“ trotzdem hörbar anders klingt.
 */
object VoiceHeuristics {
    const val FEMALE = "female"
    const val MALE = "male"
    const val NEUTRAL = "neutral"
    const val UNKNOWN = "unknown"

    private val FEMALE_NAMES: Set<String> = (
        "katja amala anna petra helena marlene vicki hedda samantha karen moira zira susan linda hazel aria jenny sonia libby maisie " +
            "emma amy salli joanna kendra kimberly ivy nicole tessa fiona veena victoria allison ava claudia birgit marie lena mia laura elena sabine " +
            "ingrid nora hanna johanna ellen tina steffi yvonne katharina sophie clara lara female weiblich frau woman girl"
        ).split(" ").toSet()

    private val MALE_NAMES: Set<String> = (
        "conrad jonas markus yannick viktor martin alex daniel david mark george guy ryan hans stefan thomas fred ralph tom " +
            "klaus jan peter paul felix max lukas tim michael andreas christian dirk florian kai jens sven killian bernd rolf male maennlich mann man boy"
        ).split(" ").toSet()

    private val SPLIT = Regex("[^a-z0-9]+")
    private val QUALITY = Regex("natural|neural|online|premium|enhanced", RegexOption.IGNORE_CASE)

    /** Eine installierte Stimme, auf das Nötigste reduziert (ohne android.speech.tts.Voice). */
    data class Candidate(val name: String, val lang: String, val local: Boolean)

    /** Liefert "female", "male" oder "unknown". */
    fun classify(name: String): String {
        val tokens = TextFold.fold(name).split(SPLIT).filter { it.isNotEmpty() }
        var f = false
        var m = false
        for (t in tokens) {
            if (t in FEMALE_NAMES) f = true
            if (t in MALE_NAMES) m = true
        }
        return when {
            f && !m -> FEMALE
            m && !f -> MALE
            else -> UNKNOWN
        }
    }

    /** Wählt aus der Liste die beste Stimme für Sprache + Geschlecht (null nur bei leerer Liste). */
    fun pickVoice(voices: List<Candidate>, gender: String, langPrefix: String = "de"): Candidate? {
        val lp = langPrefix.lowercase()
        var cand = voices.filter { it.lang.lowercase().startsWith(lp) }
        if (cand.isEmpty()) cand = voices
        fun score(v: Candidate): Int {
            var s = 0
            val c = classify(v.name)
            if (gender != NEUTRAL && c == gender) s += 10
            if (gender == NEUTRAL && c == UNKNOWN) s += 4
            if (QUALITY.containsMatchIn(v.name)) s += 3
            if (v.local) s += 1
            return s
        }
        var best: Candidate? = null
        var bestScore = -1
        for (v in cand) {
            val s = score(v)
            if (s > bestScore) {
                bestScore = s
                best = v
            }
        }
        return best
    }

    /** Tonhöhe: passt die Stimme zum Wunschgeschlecht, bleibt sie unverändert; sonst wird verschoben (male 0.82, female 1.12). */
    fun pitchFor(gender: String, voiceName: String?, basePitch: Float = 1f): Float {
        val c = if (voiceName != null) classify(voiceName) else UNKNOWN
        if (gender == NEUTRAL || c == gender) return basePitch
        val shifted = if (gender == MALE) 0.82f else 1.12f
        return (basePitch * shifted).coerceIn(0.5f, 1.5f)
    }
}
