cmake_minimum_required(VERSION 3.22.1)
project(securebrowse_jarvis LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# AGP builds debug variants with CMAKE_BUILD_TYPE=Debug. An unoptimized ggml is unusably slow,
# so the Debug flags get the Release optimization level (debug symbols stay available).
set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG -g")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG -g")

# llama.cpp options: library only, no tools, CPU backend, static so everything ends up in one .so.
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL           OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP          OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE       OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE          OFF CACHE BOOL "" FORCE)

if(NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp/CMakeLists.txt")
    message(FATAL_ERROR "llama.cpp sources missing. Run tools/add-llama-cpp.sh <tag> first.")
endif()
add_subdirectory(llama.cpp ${CMAKE_BINARY_DIR}/llama-build EXCLUDE_FROM_ALL)

add_library(jarvis_llama SHARED jarvis_jni.cpp)
target_include_directories(jarvis_llama PRIVATE llama.cpp/include llama.cpp/ggml/include)
target_link_libraries(jarvis_llama PRIVATE llama ggml log android)
# 16 KB page-size compatibility (required for Android 15+ devices / current Play rules).
target_link_options(jarvis_llama PRIVATE -Wl,-z,max-page-size=16384)
