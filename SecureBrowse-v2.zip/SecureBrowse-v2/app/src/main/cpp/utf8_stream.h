#pragma once
// Token pieces from llama.cpp are raw bytes. A single UTF-8 character (umlaut, euro sign, emoji)
// can be split across two tokens. Passing a half character to Java would produce garbage, so we
// hold back an unfinished tail until the next token completes it.
#include <cstddef>
#include <string>

namespace jarvis {

class Utf8Stream {
public:
    // Appends bytes and returns the longest prefix that does not end inside a multi-byte sequence.
    std::string push(const char* data, size_t len) {
        pending_.append(data, len);
        const size_t cut = complete_prefix_length(pending_);
        std::string out = pending_.substr(0, cut);
        pending_.erase(0, cut);
        return out;
    }

    // Returns whatever is left (possibly an incomplete sequence; Java will show U+FFFD for it).
    std::string flush() {
        std::string out;
        out.swap(pending_);
        return out;
    }

private:
    static size_t complete_prefix_length(const std::string& s) {
        const size_t n = s.size();
        for (size_t back = 1; back <= 3 && back <= n; ++back) {
            const unsigned char c = static_cast<unsigned char>(s[n - back]);
            if ((c & 0xC0) == 0x80) continue;  // continuation byte: look further back for the lead byte
            size_t need = 1;
            if (c >= 0xF0 && c <= 0xF4) need = 4;
            else if (c >= 0xE0 && c < 0xF0) need = 3;
            else if (c >= 0xC2 && c < 0xE0) need = 2;
            return need > back ? n - back : n;
        }
        return n;
    }

    std::string pending_;
};

}  // namespace jarvis
