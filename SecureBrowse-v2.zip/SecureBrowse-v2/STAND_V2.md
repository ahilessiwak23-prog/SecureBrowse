# Stand Version 2 (22.11.2026)

FERTIG + GETESTET: web/securebrowse-jarvis.html (Handy-Browser öffnen; Kamera/Mikro/Google brauchen HTTPS, z. B. GitHub Pages)
- Blaue JARVIS-Oberfläche (Farbe wechselbar), Kamera, Mikrofon, Stimmen männlich/weiblich/neutral
- Einstellungen, Info, 10x auf Version tippen -> Admin-Schalter -> Passwort -> API-Schlüssel (verschlüsselt)
- Konto per E-Mail (lokal); Google/Apple nur vorbereitet (brauchen eigene IDs)
- Virenschutz, Schutz vor Waffen/Drogen, Inkognito, Cache/Speicher, 9 Farben, 8 Hintergründe + eigenes Foto
- Tests: node web/tests/run-vectors.js (325 ok), node web/tests/e2e.cjs (9 ok)

NICHT FERTIG: die Android-App (Kotlin) hat nur Schutzfilter/Scanner/Stimmen-Logik (ungebaut). Neue Android-Oberfläche fehlt; Plan: docs/SPEC.md.
Hinweis: Das Admin-Passwort ist nur eine Bequemlichkeits-Sperre, kein echter Schutz.

## Nachtrag 22.11.2026
- App heißt jetzt **NEXORA** (Web + Android app_name), neues Original-Icon (Schild mit N und Funke), neues Design (Violett/Blau-Verlauf, Glas-Karten, Glow).
- Neu in der Web-Version: Plüschtier-Maskottchen, Cookie-/Datenschutz-Hinweis, Downloader, Besucher-Einstellungen (Suchmaschine, Schriftgröße, Kontrast, Auto-Löschen).
- Bekannte Grenze: Der Schutzfilter erkennt Text nicht, wenn zwischen jedem Buchstaben ein Leerzeichen steht.
- Android-Oberfläche für die neuen Funktionen fehlt noch; das Icon/der Name sind in Android Studio ungetestet.
